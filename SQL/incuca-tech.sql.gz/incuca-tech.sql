# Migração da Base de Dados MySQL do WordPress
#
# Gerado: Saturday 21. May 2022 16:20 UTC
# Nome do Servidor: localhost
# Banco de Dados: `incuca-tech`
# URL: //localhost/incuca-tech
# Path: C:\\xampp\\htdocs\\incuca-tech
# Tables: cuca_commentmeta, cuca_comments, cuca_links, cuca_options, cuca_postmeta, cuca_posts, cuca_term_relationships, cuca_term_taxonomy, cuca_termmeta, cuca_terms, cuca_usermeta, cuca_users, cuca_yoast_indexable, cuca_yoast_indexable_hierarchy, cuca_yoast_migrations, cuca_yoast_primary_term, cuca_yoast_seo_links
# Table Prefix: cuca_
# Post Types: revision, acf-field, acf-field-group, attachment, customize_changeset, nav_menu_item, oembed_cache, page, post, wpcf7_contact_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Apagar qualquer tabela `cuca_commentmeta` existente
#

DROP TABLE IF EXISTS `cuca_commentmeta`;


#
# Estrutura da tabela `cuca_commentmeta`
#

CREATE TABLE `cuca_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_commentmeta`
#

#
# Fim do conteúdo da tabela `cuca_commentmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_comments` existente
#

DROP TABLE IF EXISTS `cuca_comments`;


#
# Estrutura da tabela `cuca_comments`
#

CREATE TABLE `cuca_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_comments`
#

#
# Fim do conteúdo da tabela `cuca_comments`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_links` existente
#

DROP TABLE IF EXISTS `cuca_links`;


#
# Estrutura da tabela `cuca_links`
#

CREATE TABLE `cuca_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_links`
#

#
# Fim do conteúdo da tabela `cuca_links`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_options` existente
#

DROP TABLE IF EXISTS `cuca_options`;


#
# Estrutura da tabela `cuca_options`
#

CREATE TABLE `cuca_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=619 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_options`
#
INSERT INTO `cuca_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/incuca-tech', 'yes'),
(2, 'home', 'http://localhost/incuca-tech', 'yes'),
(3, 'blogname', 'Law Firm', 'yes'),
(4, 'blogdescription', 'Reunião de raciocínio e experiência de numerosas mentes.', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'sites@gabrielfreelancer.com.br', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j \\d\\e F \\d\\e Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'j \\d\\e F \\d\\e Y, H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:98:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:39:"index.php?yoast-sitemap-xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=25&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:57:"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php";i:1;s:33:"admin-menu-editor/menu-editor.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:33:"classic-editor/classic-editor.php";i:4;s:36:"contact-form-7/wp-contact-form-7.php";i:5;s:27:"svg-support/svg-support.php";i:6;s:24:"wordpress-seo/wp-seo.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'incuca-tech', 'yes'),
(41, 'stylesheet', 'incuca-tech', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '51917', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:24:"wordpress-seo/wp-seo.php";s:14:"__return_false";}', 'no'),
(80, 'timezone_string', 'America/Sao_Paulo', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '25', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '19', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1668563361', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'cuca_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:38:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'yes') ;
INSERT INTO `cuca_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'pt_BR', 'yes'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:156:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Posts recentes</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:224:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Comentários</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Arquivos</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categorias</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:8:{i:1653151762;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1653184162;a:5:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1653184175;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1653184177;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1653184924;a:2:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1653616924;a:1:{s:16:"wpseo_ryte_fetch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1653702562;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:25:"Verificação SSL falhou.";}}', 'yes'),
(135, 'can_compress_scripts', '0', 'no'),
(150, 'finished_updating_comment_type', '1', 'yes'),
(159, 'recently_activated', 'a:0:{}', 'yes'),
(160, 'wpcf7', 'a:2:{s:7:"version";s:7:"5.5.6.1";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1653012123;s:7:"version";s:7:"5.5.6.1";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(161, 'bodhi_svgs_plugin_version', '2.4.2', 'yes'),
(162, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"18.9";}', 'yes'),
(163, 'wpseo', 'a:57:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:1;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:26:"permalink_settings_changed";s:29:"indexables_indexing_completed";b:1;s:7:"version";s:4:"18.9";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:1;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1653012124;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:36:"/%year%/%monthnum%/%day%/%postname%/";s:8:"home_url";s:28:"http://localhost/incuca-tech";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:1;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:18:"first_time_install";b:1;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";i:1653012125;}', 'yes'),
(164, 'wpseo_titles', 'a:106:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:40:"%%name%%, Autor em %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:66:"Você pesquisou por %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:44:"Página não encontrada %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:54:"O post %%POSTLINK%% apareceu primeiro em %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:33:"Erro 404: Página não encontrada";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:13:"Arquivos para";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:7:"Início";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:19:"Você pesquisou por";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:53:"Arquivos %%term_title%% %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"Arquivos %%term_title%%";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:18:"title-tax-post_tag";s:53:"Arquivos %%term_title%% %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"Arquivos %%term_title%%";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:21:"title-tax-post_format";s:53:"Arquivos %%term_title%% %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"Arquivos %%term_title%%";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'yes'),
(165, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}}', 'yes') ;
INSERT INTO `cuca_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(166, 'ws_menu_editor', 'a:28:{s:22:"hide_advanced_settings";b:1;s:16:"show_extra_icons";b:0;s:11:"custom_menu";a:7:{s:4:"tree";a:21:{s:9:"index.php";a:33:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";s:23:"menu-top menu-top-first";s:8:"hookname";N;s:8:"icon_url";s:31:"dashicons-welcome-widgets-menus";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Início";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:94:"Atualizações <span class="update-plugins count-0"><span class="update-count">0</span></span>";s:12:"access_level";s:11:"update_core";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"update-core.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:15:"update-core.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Painel";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:43:"menu-top menu-top-first menu-icon-dashboard";s:8:"hookname";s:14:"menu-dashboard";s:8:"icon_url";s:19:"dashicons-dashboard";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";s:4:"read";}s:10:"upload.php";a:33:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";s:8:"menu-top";s:8:"hookname";N;s:8:"icon_url";s:24:"dashicons-format-gallery";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Biblioteca";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Adicionar nova";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"media-new.php";s:12:"page_heading";s:0:"";s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"media-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Mídia";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-media";s:8:"hookname";s:10:"menu-media";s:8:"icon_url";s:21:"dashicons-admin-media";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";s:12:"upload_files";}s:11:"separator_6";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:12:">separator_6";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_6";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:13:"general-theme";a:33:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";s:37:"menu-top  toplevel_page_general-theme";s:8:"hookname";N;s:8:"icon_url";s:23:"dashicons-media-default";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:14:">general-theme";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:10:"Tema geral";s:10:"menu_title";s:10:"Tema geral";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"general-theme";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:54:"menu-top menu-icon-generic toplevel_page_general-theme";s:8:"hookname";s:27:"toplevel_page_general-theme";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"admin.php?page=general-theme";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";s:10:"edit_posts";}s:15:"separator_J7P0l";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:16:">separator_J7P0l";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_J7P0l";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_J7P0l";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:23:"edit.php?post_type=page";a:33:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";s:8:"menu-top";s:8:"hookname";N;s:8:"icon_url";s:23:"dashicons-media-default";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:17:"Todas as páginas";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Adicionar nova";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"post-new.php?post_type=page";s:12:"page_heading";s:0:"";s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"post-new.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Páginas";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:23:"menu-top menu-icon-page";s:8:"hookname";s:10:"menu-pages";s:8:"icon_url";s:20:"dashicons-admin-page";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";s:10:"edit_pages";}s:8:"edit.php";a:33:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";s:23:"menu-top  open-if-no-js";s:8:"hookname";N;s:8:"icon_url";s:23:"dashicons-media-default";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Todos os posts";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Adicionar novo";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"post-new.php";s:12:"page_heading";s:0:"";s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"post-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Categorias";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=category";s:12:"page_heading";s:0:"";s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=category";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Tags";s:12:"access_level";s:16:"manage_post_tags";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=post_tag";s:12:"page_heading";s:0:"";s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=post_tag";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Posts";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:37:"menu-top menu-icon-post open-if-no-js";s:8:"hookname";s:10:"menu-posts";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";s:10:"edit_posts";}s:11:"separator_7";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:12:">separator_7";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_7";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:10:"themes.php";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:84:"Temas <span class="update-plugins count-0"><span class="theme-count">0</span></span>";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Personalizar";s:12:"access_level";s:9:"customize";s:16:"extra_capability";s:0:"";s:4:"file";s:89:"customize.php?return=%2Fincuca-tech%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor";s:12:"page_heading";s:0:"";s:6:"parent";s:10:"themes.php";s:9:"css_class";s:20:"hide-if-no-customize";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:89:"customize.php?return=%2Fincuca-tech%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Menus";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"nav-menus.php";s:12:"page_heading";s:0:"";s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"nav-menus.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:27:"themes.php>theme-editor.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:26:"Editor de arquivos de tema";s:10:"menu_title";s:26:"Editor de arquivos de tema";s:12:"access_level";s:11:"edit_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:16:"theme-editor.php";s:12:"page_heading";s:0:"";s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:16:"theme-editor.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Aparência";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:29:"menu-top menu-icon-appearance";s:8:"hookname";s:15:"menu-appearance";s:8:"icon_url";s:26:"dashicons-admin-appearance";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:9:"users.php";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:18:"Todos os usuários";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Adicionar novo";s:12:"access_level";s:12:"create_users";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"user-new.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"user-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Perfil";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"profile.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"profile.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Usuários";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-users";s:8:"hookname";s:10:"menu-users";s:8:"icon_url";s:21:"dashicons-admin-users";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:15:"separator_gHqpg";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:10;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:16:">separator_gHqpg";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_gHqpg";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_gHqpg";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"plugins.php";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:11;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:18:"Plugins instalados";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Adicionar novo";s:12:"access_level";s:15:"install_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"plugin-install.php";s:12:"page_heading";s:0:"";s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:18:"plugin-install.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:29:"plugins.php>plugin-editor.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:28:"Editor de arquivos de plugin";s:12:"access_level";s:12:"edit_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"plugin-editor.php";s:12:"page_heading";s:0:"";s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"plugin-editor.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:87:"Plugins <span class="update-plugins count-0"><span class="plugin-count">0</span></span>";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:26:"menu-top menu-icon-plugins";s:8:"hookname";s:12:"menu-plugins";s:8:"icon_url";s:23:"dashicons-admin-plugins";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:9:"tools.php";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:12;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:7:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:24:"Ferramentas disponíveis";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Importar";s:12:"access_level";s:6:"import";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"import.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"import.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Exportar";s:12:"access_level";s:6:"export";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"export.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"export.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:25:"tools.php>site-health.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Diagnóstico";s:12:"access_level";s:23:"view_site_health_checks";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"site-health.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:15:"site-health.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:34:"tools.php>export-personal-data.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:23:"Exportar dados pessoais";s:12:"access_level";s:27:"export_others_personal_data";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"export-personal-data.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:24:"export-personal-data.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:33:"tools.php>erase-personal-data.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:21:"Apagar dados pessoais";s:12:"access_level";s:26:"erase_others_personal_data";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"erase-personal-data.php";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"erase-personal-data.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:23:"tools.php>wp-migrate-db";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:10:"WP Migrate";s:10:"menu_title";s:10:"WP Migrate";s:12:"access_level";s:6:"export";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"wp-migrate-db";s:12:"page_heading";s:0:"";s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"tools.php?page=wp-migrate-db";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Ferramentas";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-tools";s:8:"hookname";s:10:"menu-tools";s:8:"icon_url";s:21:"dashicons-admin-tools";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:19:"options-general.php";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:13;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:9:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Geral";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Escrita";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-writing.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-writing.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Leitura";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-reading.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-reading.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Discussão";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"options-discussion.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"options-discussion.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Mídia";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"options-media.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"options-media.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:17:"Links permanentes";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:21:"options-permalink.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:21:"options-permalink.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:39:"options-general.php>options-privacy.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Privacidade";s:12:"access_level";s:22:"manage_privacy_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-privacy.php";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-privacy.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:31:"options-general.php>svg-support";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:30:"SVG Support Settings and Usage";s:10:"menu_title";s:11:"SVG Support";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"svg-support";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"options-general.php?page=svg-support";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:8;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:11:"Menu Editor";s:10:"menu_title";s:11:"Menu Editor";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"menu_editor";s:12:"page_heading";s:0:"";s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"options-general.php?page=menu_editor";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Configurações";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:27:"menu-top menu-icon-settings";s:8:"hookname";s:13:"menu-settings";s:8:"icon_url";s:24:"dashicons-admin-settings";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:15:"separator_cH2nt";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:14;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:16:">separator_cH2nt";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_cH2nt";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_cH2nt";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:34:"edit.php?post_type=acf-field-group";a:33:{s:10:"page_title";N;s:10:"menu_title";s:3:"ACF";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:15;s:6:"parent";N;s:9:"css_class";s:51:"menu-top toplevel_page_editpost_typeacf-field-group";s:8:"hookname";N;s:8:"icon_url";s:20:"dashicons-media-code";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:35:">edit.php?post_type=acf-field-group";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:69:"edit.php?post_type=acf-field-group>edit.php?post_type=acf-field-group";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:16:"Grupos de Campos";s:10:"menu_title";s:16:"Grupos de Campos";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"edit.php?post_type=acf-field-group";s:12:"page_heading";s:0:"";s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"edit.php?post_type=acf-field-group";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:73:"edit.php?post_type=acf-field-group>post-new.php?post_type=acf-field-group";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:14:"Adicionar Novo";s:10:"menu_title";s:14:"Adicionar Novo";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:38:"post-new.php?post_type=acf-field-group";s:12:"page_heading";s:0:"";s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:38:"post-new.php?post_type=acf-field-group";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:44:"edit.php?post_type=acf-field-group>acf-tools";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:11:"Ferramentas";s:10:"menu_title";s:11:"Ferramentas";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"acf-tools";s:12:"page_heading";s:0:"";s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:49:"edit.php?post_type=acf-field-group&page=acf-tools";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:55:"edit.php?post_type=acf-field-group>acf-settings-updates";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:14:"Atualizações";s:10:"menu_title";s:14:"Atualizações";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:20:"acf-settings-updates";s:12:"page_heading";s:0:"";s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:60:"edit.php?post_type=acf-field-group&page=acf-settings-updates";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:21:"Campos Personalizados";s:10:"menu_title";s:21:"Campos Personalizados";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"edit.php?post_type=acf-field-group";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:53:"menu-top toplevel_page_edit?post_type=acf-field-group";s:8:"hookname";s:44:"toplevel_page_edit?post_type=acf-field-group";s:8:"icon_url";s:31:"dashicons-welcome-widgets-menus";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"edit.php?post_type=acf-field-group";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";N;}s:5:"wpcf7";a:33:{s:10:"page_title";N;s:10:"menu_title";s:3:"CF7";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:16;s:6:"parent";N;s:9:"css_class";s:28:"menu-top toplevel_page_wpcf7";s:8:"hookname";N;s:8:"icon_url";s:20:"dashicons-media-code";s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:6:">wpcf7";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:11:"wpcf7>wpcf7";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:29:"Editar formulário de contato";s:10:"menu_title";s:23:"Formulários de contato";s:12:"access_level";s:24:"wpcf7_read_contact_forms";s:16:"extra_capability";s:0:"";s:4:"file";s:5:"wpcf7";s:12:"page_heading";s:0:"";s:6:"parent";s:5:"wpcf7";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:20:"admin.php?page=wpcf7";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:15:"wpcf7>wpcf7-new";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:37:"Adicionar novo formulário de contato";s:10:"menu_title";s:14:"Adicionar novo";s:12:"access_level";s:24:"wpcf7_edit_contact_forms";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"wpcf7-new";s:12:"page_heading";s:0:"";s:6:"parent";s:5:"wpcf7";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:24:"admin.php?page=wpcf7-new";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:23:"wpcf7>wpcf7-integration";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:28:"Integração com API externa";s:10:"menu_title";s:12:"Integração";s:12:"access_level";s:24:"wpcf7_manage_integration";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"wpcf7-integration";s:12:"page_heading";s:0:"";s:6:"parent";s:5:"wpcf7";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:32:"admin.php?page=wpcf7-integration";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:14:"Contact Form 7";s:10:"menu_title";s:7:"Contato";s:12:"access_level";s:24:"wpcf7_read_contact_forms";s:16:"extra_capability";s:0:"";s:4:"file";s:5:"wpcf7";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:28:"menu-top toplevel_page_wpcf7";s:8:"hookname";s:19:"toplevel_page_wpcf7";s:8:"icon_url";s:15:"dashicons-email";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:20:"admin.php?page=wpcf7";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";N;}s:15:"separator_f1u6U";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:17;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:16:">separator_f1u6U";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_f1u6U";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_f1u6U";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:15:"wpseo_dashboard";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:18;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:16:">wpseo_dashboard";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:6:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:31:"wpseo_dashboard>wpseo_dashboard";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:17:"Geral - Yoast SEO";s:10:"menu_title";s:5:"Geral";s:12:"access_level";s:20:"wpseo_manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"wpseo_dashboard";s:12:"page_heading";s:0:"";s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=wpseo_dashboard";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:28:"wpseo_dashboard>wpseo_titles";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:34:"Aparência na Pesquisa - Yoast SEO";s:10:"menu_title";s:22:"Aparência na Pesquisa";s:12:"access_level";s:20:"wpseo_manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"wpseo_titles";s:12:"page_heading";s:0:"";s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=wpseo_titles";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:28:"wpseo_dashboard>wpseo_social";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:25:"Redes Sociais - Yoast SEO";s:10:"menu_title";s:13:"Redes Sociais";s:12:"access_level";s:20:"wpseo_manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"wpseo_social";s:12:"page_heading";s:0:"";s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=wpseo_social";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:27:"wpseo_dashboard>wpseo_tools";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:23:"Ferramentas - Yoast SEO";s:10:"menu_title";s:11:"Ferramentas";s:12:"access_level";s:20:"wpseo_manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"wpseo_tools";s:12:"page_heading";s:0:"";s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=wpseo_tools";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:30:"wpseo_dashboard>wpseo_licenses";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:19:"Premium - Yoast SEO";s:10:"menu_title";s:7:"Premium";s:12:"access_level";s:20:"wpseo_manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"wpseo_licenses";s:12:"page_heading";s:0:"";s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=wpseo_licenses";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:30:"wpseo_dashboard>wpseo_workouts";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:73:"Treinos <span class="yoast-badge yoast-premium-badge"></span> - Yoast SEO";s:10:"menu_title";s:61:"Treinos <span class="yoast-badge yoast-premium-badge"></span>";s:12:"access_level";s:17:"edit_others_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"wpseo_workouts";s:12:"page_heading";s:0:"";s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=wpseo_workouts";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:17:"Yoast SEO: Painel";s:10:"menu_title";s:164:"Yoast SEO <span class="update-plugins count-2"><span class="plugin-count" aria-hidden="true">2</span><span class="screen-reader-text">2 notificações</span></span>";s:12:"access_level";s:20:"wpseo_manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"wpseo_dashboard";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:38:"menu-top toplevel_page_wpseo_dashboard";s:8:"hookname";s:29:"toplevel_page_wpseo_dashboard";s:8:"icon_url";s:1174:"data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgc3R5bGU9ImZpbGw6IzgyODc4YyIgdmlld0JveD0iMCAwIDUxMiA1MTIiIHJvbGU9ImltZyIgYXJpYS1oaWRkZW49InRydWUiIGZvY3VzYWJsZT0iZmFsc2UiPjxnPjxnPjxnPjxnPjxwYXRoIGQ9Ik0yMDMuNiwzOTVjNi44LTE3LjQsNi44LTM2LjYsMC01NGwtNzkuNC0yMDRoNzAuOWw0Ny43LDE0OS40bDc0LjgtMjA3LjZIMTE2LjRjLTQxLjgsMC03NiwzNC4yLTc2LDc2VjM1N2MwLDQxLjgsMzQuMiw3Niw3Niw3NkgxNzNDMTg5LDQyNC4xLDE5Ny42LDQxMC4zLDIwMy42LDM5NXoiLz48L2c+PGc+PHBhdGggZD0iTTQ3MS42LDE1NC44YzAtNDEuOC0zNC4yLTc2LTc2LTc2aC0zTDI4NS43LDM2NWMtOS42LDI2LjctMTkuNCw0OS4zLTMwLjMsNjhoMjE2LjJWMTU0Ljh6Ii8+PC9nPjwvZz48cGF0aCBzdHJva2Utd2lkdGg9IjIuOTc0IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIGQ9Ik0zMzgsMS4zbC05My4zLDI1OS4xbC00Mi4xLTEzMS45aC04OS4xbDgzLjgsMjE1LjJjNiwxNS41LDYsMzIuNSwwLDQ4Yy03LjQsMTktMTksMzcuMy01Myw0MS45bC03LjIsMXY3Nmg4LjNjODEuNywwLDExOC45LTU3LjIsMTQ5LjYtMTQyLjlMNDMxLjYsMS4zSDMzOHogTTI3OS40LDM2MmMtMzIuOSw5Mi02Ny42LDEyOC43LTEyNS43LDEzMS44di00NWMzNy41LTcuNSw1MS4zLTMxLDU5LjEtNTEuMWM3LjUtMTkuMyw3LjUtNDAuNywwLTYwbC03NS0xOTIuN2g1Mi44bDUzLjMsMTY2LjhsMTA1LjktMjk0aDU4LjFMMjc5LjQsMzYyeiIvPjwvZz48L2c+PC9zdmc+";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=wpseo_dashboard";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_8";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:19;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:12:">separator_8";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_8";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:17:"edit-comments.php";a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:20;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:1:{i:0;a:32:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:25:"is_iframe_scroll_disabled";N;s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:21:"Todos os comentários";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:6:"parent";s:17:"edit-comments.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:21:{s:10:"page_title";s:0:"";s:10:"menu_title";s:213:"Comentários <span class="awaiting-mod count-0"><span class="pending-count" aria-hidden="true">0</span><span class="comments-in-moderation-text screen-reader-text">0 comentário esperando moderação</span></span>";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:6:"parent";N;s:9:"css_class";s:27:"menu-top menu-icon-comments";s:8:"hookname";s:13:"menu-comments";s:8:"icon_url";s:24:"dashicons-admin-comments";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:25:"is_iframe_scroll_disabled";b:0;s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:6:"format";a:3:{s:4:"name";s:22:"Admin Menu Editor menu";s:7:"version";s:3:"7.0";s:13:"is_normalized";b:1;}s:13:"color_presets";a:0:{}s:20:"component_visibility";a:0:{}s:22:"has_modified_dashicons";b:1;s:16:"last_modified_on";s:25:"2022-05-20T02:07:17+00:00";s:21:"prebuilt_virtual_caps";a:2:{i:2;a:0:{}i:3;a:0:{}}}s:19:"custom_network_menu";N;s:18:"first_install_time";i:1653012124;s:21:"display_survey_notice";b:1;s:17:"plugin_db_version";i:140;s:24:"security_logging_enabled";b:0;s:17:"menu_config_scope";s:6:"global";s:13:"plugin_access";s:14:"manage_options";s:15:"allowed_user_id";N;s:28:"plugins_page_allowed_user_id";N;s:27:"show_deprecated_hide_button";b:1;s:37:"dashboard_hiding_confirmation_enabled";b:1;s:21:"submenu_icons_enabled";s:9:"if_custom";s:22:"force_custom_dashicons";b:1;s:16:"ui_colour_scheme";s:7:"classic";s:13:"visible_users";a:0:{}s:23:"show_plugin_menu_notice";b:0;s:20:"unused_item_position";s:8:"relative";s:23:"unused_item_permissions";s:9:"unchanged";s:15:"error_verbosity";i:2;s:20:"compress_custom_menu";b:0;s:20:"wpml_support_enabled";b:1;s:24:"bbpress_override_enabled";b:0;s:20:"deep_nesting_enabled";N;s:24:"was_nesting_ever_changed";b:0;s:16:"is_active_module";a:1:{s:19:"highlight-new-menus";b:0;}}', 'yes') ;
INSERT INTO `cuca_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(169, 'acf_version', '5.12.2', 'yes'),
(205, 'theme_mods_twentytwentytwo', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1653012418;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(206, 'current_theme', 'InCuca Tech', 'yes'),
(207, 'theme_mods_incuca-tech', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(208, 'theme_switched', '', 'yes'),
(209, 'options_contato_email', 'oi@lawfirm.com', 'no'),
(210, '_options_contato_email', 'field_6286f85812b62', 'no'),
(211, 'options_contato_telefone_0_sub_numero', '(48) 3344 9944', 'no'),
(212, '_options_contato_telefone_0_sub_numero', 'field_6286f81912b5d', 'no'),
(213, 'options_contato_telefone_1_sub_numero', '(48) 3564 9944', 'no'),
(214, '_options_contato_telefone_1_sub_numero', 'field_6286f81912b5d', 'no'),
(215, 'options_contato_telefone', '2', 'no'),
(216, '_options_contato_telefone', 'field_6286f7ff12b5c', 'no'),
(217, 'options_contato_endereco', 'Rua Padre Roma, 482 - Centro\r\nFlorianópolis - Santa Catarina', 'no'),
(218, '_options_contato_endereco', 'field_6286f86a12b63', 'no'),
(219, 'options_contato_mapa', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3536.031794058112!2d-48.557228449457924!3d-27.592543882755358!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9527381f601a21a3%3A0x84face800640d068!2sRua%20Padre%20Roma%2C%20482%20-%20Centro%2C%20Florian%C3%B3polis%20-%20SC%2C%2088010-090!5e0!3m2!1sen!2sbr!4v1653012685440!5m2!1sen!2sbr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>', 'no'),
(220, '_options_contato_mapa', 'field_6286f89a12b65', 'no'),
(221, 'options_social_facebook', 'https://facebook.com', 'no'),
(222, '_options_social_facebook', 'field_6286f82e12b5f', 'no'),
(223, 'options_social_twitter', 'https://twitter.com', 'no'),
(224, '_options_social_twitter', 'field_6286f83812b60', 'no'),
(225, 'options_social_linkedin', 'https://linkedin.com', 'no'),
(226, '_options_social_linkedin', 'field_6286f84112b61', 'no'),
(228, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(229, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(237, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'yes'),
(244, 'category_children', 'a:0:{}', 'yes'),
(251, 'auto_update_plugins', 'a:18:{i:0;s:57:"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php";i:1;s:33:"admin-menu-editor/menu-editor.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:33:"classic-editor/classic-editor.php";i:5;s:63:"limit-login-attempts-reloaded/limit-login-attempts-reloaded.php";i:6;s:35:"wpcf7-recaptcha/wpcf7-recaptcha.php";i:7;s:51:"simple-google-recaptcha/simple-google-recaptcha.php";i:8;s:27:"svg-support/svg-support.php";i:9;s:23:"wordfence/wordfence.php";i:10;s:31:"wp-migrate-db/wp-migrate-db.php";i:11;s:23:"wp-rocket/wp-rocket.php";i:12;s:24:"wordpress-seo/wp-seo.php";i:13;s:40:"wordpress-seo-premium/wp-seo-premium.php";i:14;s:25:"wpseo-video/video-seo.php";i:15;s:25:"wpseo-local/local-seo.php";i:16;s:39:"wpseo-woocommerce/wpseo-woocommerce.php";i:17;s:25:"wpseo-news/wpseo-news.php";}', 'no'),
(254, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1653150010;}', 'no'),
(391, 'secret_key', 'K_&pS-h9B&[lktl5yjPH%pkEKU^czqe:-ya8]OQFy=OYx!s7;,)-RgJA1|Gn3TYM', 'no'),
(577, 'wp_calendar_block_has_published_posts', '1', 'yes') ;

#
# Fim do conteúdo da tabela `cuca_options`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_postmeta` existente
#

DROP TABLE IF EXISTS `cuca_postmeta`;


#
# Estrutura da tabela `cuca_postmeta`
#

CREATE TABLE `cuca_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=709 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_postmeta`
#
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_form', '[text* nome placeholder akismet:author "Nome"]\n[email* email placeholder akismet:author_email "E-mail"]\n[text* telefone placeholder "Telefone"]\n[textarea* mensagem placeholder "Mensagem"]\n<button>Enviar</button>'),
(4, 5, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:46:"[_site_title] <sites@gabrielfreelancer.com.br>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:178:"De: [your-name] <[your-email]>\nAssunto: [your-subject]\n\nCorpo da mensagem:\n[your-message]\n\n-- \nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(5, 5, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:46:"[_site_title] <sites@gabrielfreelancer.com.br>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:122:"Corpo da mensagem:\n[your-message]\n\n-- \nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(6, 5, '_messages', 'a:22:{s:12:"mail_sent_ok";s:27:"Agradecemos a sua mensagem.";s:12:"mail_sent_ng";s:74:"Ocorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.";s:16:"validation_error";s:63:"Um ou mais campos possuem um erro. Verifique e tente novamente.";s:4:"spam";s:74:"Ocorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.";s:12:"accept_terms";s:72:"Você deve aceitar os termos e condições antes de enviar sua mensagem.";s:16:"invalid_required";s:24:"O campo é obrigatório.";s:16:"invalid_too_long";s:23:"O campo é muito longo.";s:17:"invalid_too_short";s:23:"O campo é muito curto.";s:13:"upload_failed";s:49:"Ocorreu um erro desconhecido ao enviar o arquivo.";s:24:"upload_file_type_invalid";s:59:"Você não tem permissão para enviar esse tipo de arquivo.";s:21:"upload_file_too_large";s:26:"O arquivo é muito grande.";s:23:"upload_failed_php_error";s:36:"Ocorreu um erro ao enviar o arquivo.";s:12:"invalid_date";s:34:"O formato de data está incorreto.";s:14:"date_too_early";s:44:"A data é anterior à mais antiga permitida.";s:13:"date_too_late";s:44:"A data é posterior à maior data permitida.";s:14:"invalid_number";s:34:"O formato de número é inválido.";s:16:"number_too_small";s:46:"O número é menor do que o mínimo permitido.";s:16:"number_too_large";s:46:"O número é maior do que o máximo permitido.";s:23:"quiz_answer_not_correct";s:39:"A resposta para o quiz está incorreta.";s:13:"invalid_email";s:45:"O endereço de e-mail informado é inválido.";s:11:"invalid_url";s:19:"A URL é inválida.";s:11:"invalid_tel";s:35:"O número de telefone é inválido.";}'),
(7, 5, '_additional_settings', ''),
(8, 5, '_locale', 'pt_BR'),
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1653103438:1'),
(11, 18, '_edit_lock', '1653012992:1'),
(12, 19, '_wp_attached_file', '2022/05/favicon-law-firm.png'),
(13, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:128;s:6:"height";i:128;s:4:"file";s:28:"2022/05/favicon-law-firm.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 19, '_wp_attachment_image_alt', 'Ícone da Law Firm'),
(15, 20, '_menu_item_type', 'custom'),
(16, 20, '_menu_item_menu_item_parent', '0'),
(17, 20, '_menu_item_object_id', '20'),
(18, 20, '_menu_item_object', 'custom'),
(19, 20, '_menu_item_target', ''),
(20, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(21, 20, '_menu_item_xfn', ''),
(22, 20, '_menu_item_url', '#intro'),
(23, 21, '_menu_item_type', 'custom'),
(24, 21, '_menu_item_menu_item_parent', '0'),
(25, 21, '_menu_item_object_id', '21'),
(26, 21, '_menu_item_object', 'custom'),
(27, 21, '_menu_item_target', ''),
(28, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(29, 21, '_menu_item_xfn', ''),
(30, 21, '_menu_item_url', '#areas-de-atuacao'),
(31, 22, '_menu_item_type', 'custom'),
(32, 22, '_menu_item_menu_item_parent', '0'),
(33, 22, '_menu_item_object_id', '22'),
(34, 22, '_menu_item_object', 'custom'),
(35, 22, '_menu_item_target', ''),
(36, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(37, 22, '_menu_item_xfn', ''),
(38, 22, '_menu_item_url', '#equipe'),
(39, 23, '_menu_item_type', 'custom'),
(40, 23, '_menu_item_menu_item_parent', '0'),
(41, 23, '_menu_item_object_id', '23'),
(42, 23, '_menu_item_object', 'custom'),
(43, 23, '_menu_item_target', ''),
(44, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(45, 23, '_menu_item_xfn', ''),
(46, 23, '_menu_item_url', '#artigos'),
(47, 24, '_menu_item_type', 'custom'),
(48, 24, '_menu_item_menu_item_parent', '0'),
(49, 24, '_menu_item_object_id', '24'),
(50, 24, '_menu_item_object', 'custom'),
(51, 24, '_menu_item_target', ''),
(52, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 24, '_menu_item_xfn', ''),
(54, 24, '_menu_item_url', '#footer'),
(55, 18, '_wp_trash_meta_status', 'publish'),
(56, 18, '_wp_trash_meta_time', '1653013004'),
(57, 25, '_edit_last', '1'),
(58, 25, '_wp_page_template', 'default'),
(59, 25, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(60, 25, 'inline_featured_image', '0'),
(61, 25, '_edit_lock', '1653148557:1'),
(62, 27, '_wp_trash_meta_status', 'publish'),
(63, 27, '_wp_trash_meta_time', '1653013024'),
(64, 28, '_wp_trash_meta_status', 'publish'),
(65, 28, '_wp_trash_meta_time', '1653013034'),
(69, 30, '_edit_last', '1'),
(70, 30, '_edit_lock', '1653148496:1'),
(71, 58, '_edit_last', '1'),
(72, 58, '_edit_lock', '1653148842:1'),
(73, 3, '_edit_lock', '1653013608:1'),
(74, 3, '_edit_last', '1'),
(75, 3, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(76, 3, 'inline_featured_image', '0'),
(78, 5, '_config_errors', 'a:1:{s:23:"mail.additional_headers";a:1:{i:0;a:2:{s:4:"code";i:102;s:4:"args";a:3:{s:7:"message";s:64:"A sintaxe de caixa de e-mail usada no campo %name% é inválida.";s:6:"params";a:1:{s:4:"name";s:8:"Reply-To";}s:4:"link";s:68:"https://contactform7.com/configuration-errors/invalid-mailbox-syntax";}}}}'),
(79, 65, '_form', '[email* email placeholder akismet:author_email "Digite o seu e-mail"]<button>Enviar</button>'),
(80, 65, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:46:"[_site_title] <sites@gabrielfreelancer.com.br>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:178:"De: [your-name] <[your-email]>\nAssunto: [your-subject]\n\nCorpo da mensagem:\n[your-message]\n\n-- \nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(81, 65, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:46:"[_site_title] <sites@gabrielfreelancer.com.br>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:122:"Corpo da mensagem:\n[your-message]\n\n-- \nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(82, 65, '_messages', 'a:22:{s:12:"mail_sent_ok";s:27:"Agradecemos a sua mensagem.";s:12:"mail_sent_ng";s:74:"Ocorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.";s:16:"validation_error";s:63:"Um ou mais campos possuem um erro. Verifique e tente novamente.";s:4:"spam";s:74:"Ocorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.";s:12:"accept_terms";s:72:"Você deve aceitar os termos e condições antes de enviar sua mensagem.";s:16:"invalid_required";s:24:"O campo é obrigatório.";s:16:"invalid_too_long";s:23:"O campo é muito longo.";s:17:"invalid_too_short";s:23:"O campo é muito curto.";s:13:"upload_failed";s:49:"Ocorreu um erro desconhecido ao enviar o arquivo.";s:24:"upload_file_type_invalid";s:59:"Você não tem permissão para enviar esse tipo de arquivo.";s:21:"upload_file_too_large";s:26:"O arquivo é muito grande.";s:23:"upload_failed_php_error";s:36:"Ocorreu um erro ao enviar o arquivo.";s:12:"invalid_date";s:34:"O formato de data está incorreto.";s:14:"date_too_early";s:44:"A data é anterior à mais antiga permitida.";s:13:"date_too_late";s:44:"A data é posterior à maior data permitida.";s:14:"invalid_number";s:34:"O formato de número é inválido.";s:16:"number_too_small";s:46:"O número é menor do que o mínimo permitido.";s:16:"number_too_large";s:46:"O número é maior do que o máximo permitido.";s:23:"quiz_answer_not_correct";s:39:"A resposta para o quiz está incorreta.";s:13:"invalid_email";s:45:"O endereço de e-mail informado é inválido.";s:11:"invalid_url";s:19:"A URL é inválida.";s:11:"invalid_tel";s:35:"O número de telefone é inválido.";}'),
(83, 65, '_additional_settings', ''),
(84, 65, '_locale', 'pt_BR'),
(85, 65, '_config_errors', 'a:1:{s:23:"mail.additional_headers";a:1:{i:0;a:2:{s:4:"code";i:102;s:4:"args";a:3:{s:7:"message";s:64:"A sintaxe de caixa de e-mail usada no campo %name% é inválida.";s:6:"params";a:1:{s:4:"name";s:8:"Reply-To";}s:4:"link";s:68:"https://contactform7.com/configuration-errors/invalid-mailbox-syntax";}}}}'),
(86, 25, '_yoast_wpseo_content_score', '30'),
(87, 25, 'capa_titulo', 'Law Firm'),
(88, 25, '_capa_titulo', 'field_6286fa7904274'),
(89, 25, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(90, 25, '_capa_texto', 'field_6286fa8204275'),
(91, 25, 'capa_link', 'http://localhost/incuca-tech/404'),
(92, 25, '_capa_link', 'field_6286fa8e04276'),
(93, 25, 'capa_img_desktop', '67'),
(94, 25, '_capa_img_desktop', 'field_6286fa9504277'),
(95, 25, 'capa_img_mobile', '68'),
(96, 25, '_capa_img_mobile', 'field_6286fabd04278'),
(97, 25, 'atuacao_titulo', 'Áreas de atuação'),
(98, 25, '_atuacao_titulo', 'field_6286faee0427a'),
(99, 25, 'atuacao_link', 'http://localhost/incuca-tech/404'),
(100, 25, '_atuacao_link', 'field_6286fafc0427b'),
(101, 25, 'atuacao_cards', '4'),
(102, 25, '_atuacao_cards', 'field_6286fb070427c'),
(103, 25, 'reflexao_texto', 'Não há um único dos nossos actos que, ao criarem o homem que queremos ser, não crie ao mesmo tempo uma imagem do homem tal como estimamos que ele deve ser.'),
(104, 25, '_reflexao_texto', 'field_6286fb7004281'),
(105, 25, 'reflexao_autor', 'Jean-Paul Sartre') ;
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(106, 25, '_reflexao_autor', 'field_6286fb7c04282'),
(107, 25, 'reflexao_img', '78'),
(108, 25, '_reflexao_img', 'field_6286fb8804283'),
(109, 25, 'sobre_titulo', 'Quem somos'),
(110, 25, '_sobre_titulo', 'field_6286fbb504285'),
(111, 25, 'sobre_equipe', '4'),
(112, 25, '_sobre_equipe', 'field_6286fbc404286'),
(113, 25, 'convite_titulo', 'Como a LAW FIRM pode te ajudar?'),
(114, 25, '_convite_titulo', 'field_6286fc43c1002'),
(115, 25, 'convite_texto', 'Duvidas sobre o seu caso? Entre em contato.\r\nCurabitur ac lacus sed turpis venenatis pharetra at.'),
(116, 25, '_convite_texto', 'field_6286fc4cc1003'),
(117, 25, 'convite_link', 'http://localhost/incuca-tech/404'),
(118, 25, '_convite_link', 'field_6286fc5cc1004'),
(119, 25, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(120, 25, '_newsletter_texto', 'field_6286fcdba1a1b'),
(121, 66, 'capa_titulo', ''),
(122, 66, '_capa_titulo', 'field_6286fa7904274'),
(123, 66, 'capa_texto', ''),
(124, 66, '_capa_texto', 'field_6286fa8204275'),
(125, 66, 'capa_link', ''),
(126, 66, '_capa_link', 'field_6286fa8e04276'),
(127, 66, 'capa_img_desktop', ''),
(128, 66, '_capa_img_desktop', 'field_6286fa9504277'),
(129, 66, 'capa_img_mobile', ''),
(130, 66, '_capa_img_mobile', 'field_6286fabd04278'),
(131, 66, 'atuacao_titulo', ''),
(132, 66, '_atuacao_titulo', 'field_6286faee0427a'),
(133, 66, 'atuacao_link', ''),
(134, 66, '_atuacao_link', 'field_6286fafc0427b'),
(135, 66, 'atuacao_cards', ''),
(136, 66, '_atuacao_cards', 'field_6286fb070427c'),
(137, 66, 'reflexao_texto', ''),
(138, 66, '_reflexao_texto', 'field_6286fb7004281'),
(139, 66, 'reflexao_autor', ''),
(140, 66, '_reflexao_autor', 'field_6286fb7c04282'),
(141, 66, 'reflexao_img', ''),
(142, 66, '_reflexao_img', 'field_6286fb8804283'),
(143, 66, 'sobre_titulo', ''),
(144, 66, '_sobre_titulo', 'field_6286fbb504285'),
(145, 66, 'sobre_equipe', ''),
(146, 66, '_sobre_equipe', 'field_6286fbc404286'),
(147, 66, 'convite_titulo', ''),
(148, 66, '_convite_titulo', 'field_6286fc43c1002'),
(149, 66, 'convite_texto', ''),
(150, 66, '_convite_texto', 'field_6286fc4cc1003'),
(151, 66, 'convite_link', ''),
(152, 66, '_convite_link', 'field_6286fc5cc1004'),
(153, 66, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(154, 66, '_newsletter_texto', 'field_6286fcdba1a1b'),
(155, 20, '_wp_old_date', '2022-05-19'),
(156, 21, '_wp_old_date', '2022-05-19'),
(157, 22, '_wp_old_date', '2022-05-19'),
(158, 23, '_wp_old_date', '2022-05-19'),
(159, 24, '_wp_old_date', '2022-05-19'),
(160, 67, '_wp_attached_file', '2022/05/hero-desktop.png'),
(161, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1400;s:6:"height";i:400;s:4:"file";s:24:"2022/05/hero-desktop.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(162, 68, '_wp_attached_file', '2022/05/hero-mobile.png'),
(163, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:768;s:6:"height";i:900;s:4:"file";s:23:"2022/05/hero-mobile.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(164, 69, 'capa_titulo', 'Law Firm'),
(165, 69, '_capa_titulo', 'field_6286fa7904274'),
(166, 69, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(167, 69, '_capa_texto', 'field_6286fa8204275'),
(168, 69, 'capa_link', 'http://localhost/incuca-tech'),
(169, 69, '_capa_link', 'field_6286fa8e04276'),
(170, 69, 'capa_img_desktop', '67'),
(171, 69, '_capa_img_desktop', 'field_6286fa9504277'),
(172, 69, 'capa_img_mobile', '68'),
(173, 69, '_capa_img_mobile', 'field_6286fabd04278'),
(174, 69, 'atuacao_titulo', ''),
(175, 69, '_atuacao_titulo', 'field_6286faee0427a'),
(176, 69, 'atuacao_link', ''),
(177, 69, '_atuacao_link', 'field_6286fafc0427b'),
(178, 69, 'atuacao_cards', ''),
(179, 69, '_atuacao_cards', 'field_6286fb070427c'),
(180, 69, 'reflexao_texto', ''),
(181, 69, '_reflexao_texto', 'field_6286fb7004281'),
(182, 69, 'reflexao_autor', ''),
(183, 69, '_reflexao_autor', 'field_6286fb7c04282'),
(184, 69, 'reflexao_img', ''),
(185, 69, '_reflexao_img', 'field_6286fb8804283'),
(186, 69, 'sobre_titulo', ''),
(187, 69, '_sobre_titulo', 'field_6286fbb504285'),
(188, 69, 'sobre_equipe', ''),
(189, 69, '_sobre_equipe', 'field_6286fbc404286'),
(190, 69, 'convite_titulo', ''),
(191, 69, '_convite_titulo', 'field_6286fc43c1002'),
(192, 69, 'convite_texto', ''),
(193, 69, '_convite_texto', 'field_6286fc4cc1003'),
(194, 69, 'convite_link', ''),
(195, 69, '_convite_link', 'field_6286fc5cc1004'),
(196, 69, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(197, 69, '_newsletter_texto', 'field_6286fcdba1a1b'),
(198, 70, 'capa_titulo', 'Law Firm'),
(199, 70, '_capa_titulo', 'field_6286fa7904274'),
(200, 70, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(201, 70, '_capa_texto', 'field_6286fa8204275'),
(202, 70, 'capa_link', 'http://localhost/incuca-tech/404'),
(203, 70, '_capa_link', 'field_6286fa8e04276'),
(204, 70, 'capa_img_desktop', '67'),
(205, 70, '_capa_img_desktop', 'field_6286fa9504277') ;
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(206, 70, 'capa_img_mobile', '68'),
(207, 70, '_capa_img_mobile', 'field_6286fabd04278'),
(208, 70, 'atuacao_titulo', ''),
(209, 70, '_atuacao_titulo', 'field_6286faee0427a'),
(210, 70, 'atuacao_link', ''),
(211, 70, '_atuacao_link', 'field_6286fafc0427b'),
(212, 70, 'atuacao_cards', ''),
(213, 70, '_atuacao_cards', 'field_6286fb070427c'),
(214, 70, 'reflexao_texto', ''),
(215, 70, '_reflexao_texto', 'field_6286fb7004281'),
(216, 70, 'reflexao_autor', ''),
(217, 70, '_reflexao_autor', 'field_6286fb7c04282'),
(218, 70, 'reflexao_img', ''),
(219, 70, '_reflexao_img', 'field_6286fb8804283'),
(220, 70, 'sobre_titulo', ''),
(221, 70, '_sobre_titulo', 'field_6286fbb504285'),
(222, 70, 'sobre_equipe', ''),
(223, 70, '_sobre_equipe', 'field_6286fbc404286'),
(224, 70, 'convite_titulo', ''),
(225, 70, '_convite_titulo', 'field_6286fc43c1002'),
(226, 70, 'convite_texto', ''),
(227, 70, '_convite_texto', 'field_6286fc4cc1003'),
(228, 70, 'convite_link', ''),
(229, 70, '_convite_link', 'field_6286fc5cc1004'),
(230, 70, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(231, 70, '_newsletter_texto', 'field_6286fcdba1a1b'),
(232, 71, '_wp_attached_file', '2022/05/atuacao-01.png'),
(233, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:86;s:6:"height";i:113;s:4:"file";s:22:"2022/05/atuacao-01.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(234, 72, '_wp_attached_file', '2022/05/atuacao-02.png'),
(235, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:111;s:6:"height";i:111;s:4:"file";s:22:"2022/05/atuacao-02.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(236, 73, '_wp_attached_file', '2022/05/atuacao-03.png'),
(237, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:96;s:6:"height";i:96;s:4:"file";s:22:"2022/05/atuacao-03.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(238, 74, '_wp_attached_file', '2022/05/atuacao-04.png'),
(239, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:112;s:6:"height";i:114;s:4:"file";s:22:"2022/05/atuacao-04.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(240, 71, '_wp_attachment_image_alt', 'Ícone de atuação 1'),
(241, 72, '_wp_attachment_image_alt', 'Ícone de atuação 2'),
(242, 73, '_wp_attachment_image_alt', 'Ícone de atuação 3'),
(243, 74, '_wp_attachment_image_alt', 'Ícone de atuação 4'),
(244, 68, '_wp_attachment_image_alt', 'Homem fazendo anotações'),
(245, 67, '_wp_attachment_image_alt', 'Homem fazendo anotações'),
(246, 25, 'atuacao_cards_0_sub_icone', '71'),
(247, 25, '_atuacao_cards_0_sub_icone', 'field_6286fb200427d'),
(248, 25, 'atuacao_cards_0_sub_titulo', 'Atuação 01'),
(249, 25, '_atuacao_cards_0_sub_titulo', 'field_6286fb330427e'),
(250, 25, 'atuacao_cards_0_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(251, 25, '_atuacao_cards_0_sub_texto', 'field_6286fb3a0427f'),
(252, 25, 'atuacao_cards_1_sub_icone', '72'),
(253, 25, '_atuacao_cards_1_sub_icone', 'field_6286fb200427d'),
(254, 25, 'atuacao_cards_1_sub_titulo', 'Atuação 02'),
(255, 25, '_atuacao_cards_1_sub_titulo', 'field_6286fb330427e'),
(256, 25, 'atuacao_cards_1_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(257, 25, '_atuacao_cards_1_sub_texto', 'field_6286fb3a0427f'),
(258, 25, 'atuacao_cards_2_sub_icone', '73'),
(259, 25, '_atuacao_cards_2_sub_icone', 'field_6286fb200427d'),
(260, 25, 'atuacao_cards_2_sub_titulo', 'Atuação 03'),
(261, 25, '_atuacao_cards_2_sub_titulo', 'field_6286fb330427e'),
(262, 25, 'atuacao_cards_2_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(263, 25, '_atuacao_cards_2_sub_texto', 'field_6286fb3a0427f'),
(264, 25, 'atuacao_cards_3_sub_icone', '74'),
(265, 25, '_atuacao_cards_3_sub_icone', 'field_6286fb200427d'),
(266, 25, 'atuacao_cards_3_sub_titulo', 'Atuação 04'),
(267, 25, '_atuacao_cards_3_sub_titulo', 'field_6286fb330427e'),
(268, 25, 'atuacao_cards_3_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(269, 25, '_atuacao_cards_3_sub_texto', 'field_6286fb3a0427f'),
(270, 75, 'capa_titulo', 'Law Firm'),
(271, 75, '_capa_titulo', 'field_6286fa7904274'),
(272, 75, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(273, 75, '_capa_texto', 'field_6286fa8204275'),
(274, 75, 'capa_link', 'http://localhost/incuca-tech/404'),
(275, 75, '_capa_link', 'field_6286fa8e04276'),
(276, 75, 'capa_img_desktop', '67'),
(277, 75, '_capa_img_desktop', 'field_6286fa9504277'),
(278, 75, 'capa_img_mobile', '68'),
(279, 75, '_capa_img_mobile', 'field_6286fabd04278'),
(280, 75, 'atuacao_titulo', 'Áreas de atuação'),
(281, 75, '_atuacao_titulo', 'field_6286faee0427a'),
(282, 75, 'atuacao_link', 'http://localhost/incuca-tech/404'),
(283, 75, '_atuacao_link', 'field_6286fafc0427b'),
(284, 75, 'atuacao_cards', '4'),
(285, 75, '_atuacao_cards', 'field_6286fb070427c'),
(286, 75, 'reflexao_texto', ''),
(287, 75, '_reflexao_texto', 'field_6286fb7004281'),
(288, 75, 'reflexao_autor', ''),
(289, 75, '_reflexao_autor', 'field_6286fb7c04282'),
(290, 75, 'reflexao_img', ''),
(291, 75, '_reflexao_img', 'field_6286fb8804283'),
(292, 75, 'sobre_titulo', ''),
(293, 75, '_sobre_titulo', 'field_6286fbb504285'),
(294, 75, 'sobre_equipe', ''),
(295, 75, '_sobre_equipe', 'field_6286fbc404286'),
(296, 75, 'convite_titulo', ''),
(297, 75, '_convite_titulo', 'field_6286fc43c1002'),
(298, 75, 'convite_texto', ''),
(299, 75, '_convite_texto', 'field_6286fc4cc1003'),
(300, 75, 'convite_link', ''),
(301, 75, '_convite_link', 'field_6286fc5cc1004'),
(302, 75, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(303, 75, '_newsletter_texto', 'field_6286fcdba1a1b'),
(304, 75, 'atuacao_cards_0_sub_icone', '71'),
(305, 75, '_atuacao_cards_0_sub_icone', 'field_6286fb200427d') ;
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(306, 75, 'atuacao_cards_0_sub_titulo', 'Atuação 01'),
(307, 75, '_atuacao_cards_0_sub_titulo', 'field_6286fb330427e'),
(308, 75, 'atuacao_cards_0_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(309, 75, '_atuacao_cards_0_sub_texto', 'field_6286fb3a0427f'),
(310, 75, 'atuacao_cards_1_sub_icone', '72'),
(311, 75, '_atuacao_cards_1_sub_icone', 'field_6286fb200427d'),
(312, 75, 'atuacao_cards_1_sub_titulo', 'Atuação 02'),
(313, 75, '_atuacao_cards_1_sub_titulo', 'field_6286fb330427e'),
(314, 75, 'atuacao_cards_1_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(315, 75, '_atuacao_cards_1_sub_texto', 'field_6286fb3a0427f'),
(316, 75, 'atuacao_cards_2_sub_icone', '73'),
(317, 75, '_atuacao_cards_2_sub_icone', 'field_6286fb200427d'),
(318, 75, 'atuacao_cards_2_sub_titulo', 'Atuação 03'),
(319, 75, '_atuacao_cards_2_sub_titulo', 'field_6286fb330427e'),
(320, 75, 'atuacao_cards_2_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(321, 75, '_atuacao_cards_2_sub_texto', 'field_6286fb3a0427f'),
(322, 75, 'atuacao_cards_3_sub_icone', '74'),
(323, 75, '_atuacao_cards_3_sub_icone', 'field_6286fb200427d'),
(324, 75, 'atuacao_cards_3_sub_titulo', 'Atuação 04'),
(325, 75, '_atuacao_cards_3_sub_titulo', 'field_6286fb330427e'),
(326, 75, 'atuacao_cards_3_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(327, 75, '_atuacao_cards_3_sub_texto', 'field_6286fb3a0427f'),
(330, 77, 'capa_titulo', 'Law Firm'),
(331, 77, '_capa_titulo', 'field_6286fa7904274'),
(332, 77, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(333, 77, '_capa_texto', 'field_6286fa8204275'),
(334, 77, 'capa_link', 'http://localhost/incuca-tech/404'),
(335, 77, '_capa_link', 'field_6286fa8e04276'),
(336, 77, 'capa_img_desktop', '67'),
(337, 77, '_capa_img_desktop', 'field_6286fa9504277'),
(338, 77, 'capa_img_mobile', '68'),
(339, 77, '_capa_img_mobile', 'field_6286fabd04278'),
(340, 77, 'atuacao_titulo', 'Áreas de atuação'),
(341, 77, '_atuacao_titulo', 'field_6286faee0427a'),
(342, 77, 'atuacao_link', 'http://localhost/incuca-tech/404'),
(343, 77, '_atuacao_link', 'field_6286fafc0427b'),
(344, 77, 'atuacao_cards', '4'),
(345, 77, '_atuacao_cards', 'field_6286fb070427c'),
(346, 77, 'reflexao_texto', 'Não há um único dos nossos actos que, ao criarem o homem que queremos ser, não crie ao mesmo tempo uma imagem do homem tal como estimamos que ele deve ser.'),
(347, 77, '_reflexao_texto', 'field_6286fb7004281'),
(348, 77, 'reflexao_autor', 'Jean-Paul Sartre'),
(349, 77, '_reflexao_autor', 'field_6286fb7c04282'),
(350, 77, 'reflexao_img', '76'),
(351, 77, '_reflexao_img', 'field_6286fb8804283'),
(352, 77, 'sobre_titulo', ''),
(353, 77, '_sobre_titulo', 'field_6286fbb504285'),
(354, 77, 'sobre_equipe', ''),
(355, 77, '_sobre_equipe', 'field_6286fbc404286'),
(356, 77, 'convite_titulo', ''),
(357, 77, '_convite_titulo', 'field_6286fc43c1002'),
(358, 77, 'convite_texto', ''),
(359, 77, '_convite_texto', 'field_6286fc4cc1003'),
(360, 77, 'convite_link', ''),
(361, 77, '_convite_link', 'field_6286fc5cc1004'),
(362, 77, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(363, 77, '_newsletter_texto', 'field_6286fcdba1a1b'),
(364, 77, 'atuacao_cards_0_sub_icone', '71'),
(365, 77, '_atuacao_cards_0_sub_icone', 'field_6286fb200427d'),
(366, 77, 'atuacao_cards_0_sub_titulo', 'Atuação 01'),
(367, 77, '_atuacao_cards_0_sub_titulo', 'field_6286fb330427e'),
(368, 77, 'atuacao_cards_0_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(369, 77, '_atuacao_cards_0_sub_texto', 'field_6286fb3a0427f'),
(370, 77, 'atuacao_cards_1_sub_icone', '72'),
(371, 77, '_atuacao_cards_1_sub_icone', 'field_6286fb200427d'),
(372, 77, 'atuacao_cards_1_sub_titulo', 'Atuação 02'),
(373, 77, '_atuacao_cards_1_sub_titulo', 'field_6286fb330427e'),
(374, 77, 'atuacao_cards_1_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(375, 77, '_atuacao_cards_1_sub_texto', 'field_6286fb3a0427f'),
(376, 77, 'atuacao_cards_2_sub_icone', '73'),
(377, 77, '_atuacao_cards_2_sub_icone', 'field_6286fb200427d'),
(378, 77, 'atuacao_cards_2_sub_titulo', 'Atuação 03'),
(379, 77, '_atuacao_cards_2_sub_titulo', 'field_6286fb330427e'),
(380, 77, 'atuacao_cards_2_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(381, 77, '_atuacao_cards_2_sub_texto', 'field_6286fb3a0427f'),
(382, 77, 'atuacao_cards_3_sub_icone', '74'),
(383, 77, '_atuacao_cards_3_sub_icone', 'field_6286fb200427d'),
(384, 77, 'atuacao_cards_3_sub_titulo', 'Atuação 04'),
(385, 77, '_atuacao_cards_3_sub_titulo', 'field_6286fb330427e'),
(386, 77, 'atuacao_cards_3_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(387, 77, '_atuacao_cards_3_sub_texto', 'field_6286fb3a0427f'),
(388, 78, '_wp_attached_file', '2022/05/reflexxao.png'),
(389, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1080;s:4:"file";s:21:"2022/05/reflexxao.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(390, 78, '_wp_attachment_image_alt', 'Balança como símbolo da justiça'),
(391, 79, 'capa_titulo', 'Law Firm'),
(392, 79, '_capa_titulo', 'field_6286fa7904274'),
(393, 79, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(394, 79, '_capa_texto', 'field_6286fa8204275'),
(395, 79, 'capa_link', 'http://localhost/incuca-tech/404'),
(396, 79, '_capa_link', 'field_6286fa8e04276'),
(397, 79, 'capa_img_desktop', '67'),
(398, 79, '_capa_img_desktop', 'field_6286fa9504277'),
(399, 79, 'capa_img_mobile', '68'),
(400, 79, '_capa_img_mobile', 'field_6286fabd04278'),
(401, 79, 'atuacao_titulo', 'Áreas de atuação'),
(402, 79, '_atuacao_titulo', 'field_6286faee0427a'),
(403, 79, 'atuacao_link', 'http://localhost/incuca-tech/404'),
(404, 79, '_atuacao_link', 'field_6286fafc0427b'),
(405, 79, 'atuacao_cards', '4'),
(406, 79, '_atuacao_cards', 'field_6286fb070427c'),
(407, 79, 'reflexao_texto', 'Não há um único dos nossos actos que, ao criarem o homem que queremos ser, não crie ao mesmo tempo uma imagem do homem tal como estimamos que ele deve ser.') ;
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(408, 79, '_reflexao_texto', 'field_6286fb7004281'),
(409, 79, 'reflexao_autor', 'Jean-Paul Sartre'),
(410, 79, '_reflexao_autor', 'field_6286fb7c04282'),
(411, 79, 'reflexao_img', '78'),
(412, 79, '_reflexao_img', 'field_6286fb8804283'),
(413, 79, 'sobre_titulo', ''),
(414, 79, '_sobre_titulo', 'field_6286fbb504285'),
(415, 79, 'sobre_equipe', ''),
(416, 79, '_sobre_equipe', 'field_6286fbc404286'),
(417, 79, 'convite_titulo', ''),
(418, 79, '_convite_titulo', 'field_6286fc43c1002'),
(419, 79, 'convite_texto', ''),
(420, 79, '_convite_texto', 'field_6286fc4cc1003'),
(421, 79, 'convite_link', ''),
(422, 79, '_convite_link', 'field_6286fc5cc1004'),
(423, 79, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(424, 79, '_newsletter_texto', 'field_6286fcdba1a1b'),
(425, 79, 'atuacao_cards_0_sub_icone', '71'),
(426, 79, '_atuacao_cards_0_sub_icone', 'field_6286fb200427d'),
(427, 79, 'atuacao_cards_0_sub_titulo', 'Atuação 01'),
(428, 79, '_atuacao_cards_0_sub_titulo', 'field_6286fb330427e'),
(429, 79, 'atuacao_cards_0_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(430, 79, '_atuacao_cards_0_sub_texto', 'field_6286fb3a0427f'),
(431, 79, 'atuacao_cards_1_sub_icone', '72'),
(432, 79, '_atuacao_cards_1_sub_icone', 'field_6286fb200427d'),
(433, 79, 'atuacao_cards_1_sub_titulo', 'Atuação 02'),
(434, 79, '_atuacao_cards_1_sub_titulo', 'field_6286fb330427e'),
(435, 79, 'atuacao_cards_1_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(436, 79, '_atuacao_cards_1_sub_texto', 'field_6286fb3a0427f'),
(437, 79, 'atuacao_cards_2_sub_icone', '73'),
(438, 79, '_atuacao_cards_2_sub_icone', 'field_6286fb200427d'),
(439, 79, 'atuacao_cards_2_sub_titulo', 'Atuação 03'),
(440, 79, '_atuacao_cards_2_sub_titulo', 'field_6286fb330427e'),
(441, 79, 'atuacao_cards_2_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(442, 79, '_atuacao_cards_2_sub_texto', 'field_6286fb3a0427f'),
(443, 79, 'atuacao_cards_3_sub_icone', '74'),
(444, 79, '_atuacao_cards_3_sub_icone', 'field_6286fb200427d'),
(445, 79, 'atuacao_cards_3_sub_titulo', 'Atuação 04'),
(446, 79, '_atuacao_cards_3_sub_titulo', 'field_6286fb330427e'),
(447, 79, 'atuacao_cards_3_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(448, 79, '_atuacao_cards_3_sub_texto', 'field_6286fb3a0427f'),
(449, 80, '_wp_attached_file', '2022/05/marcos-junior.png'),
(450, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:152;s:6:"height";i:319;s:4:"file";s:25:"2022/05/marcos-junior.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(451, 81, '_wp_attached_file', '2022/05/laura-da-silva.png'),
(452, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:152;s:6:"height";i:318;s:4:"file";s:26:"2022/05/laura-da-silva.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(453, 82, '_wp_attached_file', '2022/05/andre-augusto.png'),
(454, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:152;s:6:"height";i:318;s:4:"file";s:25:"2022/05/andre-augusto.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(455, 83, '_wp_attached_file', '2022/05/carol-santos.png'),
(456, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:152;s:6:"height";i:319;s:4:"file";s:24:"2022/05/carol-santos.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(457, 80, '_wp_attachment_image_alt', 'Marcos Junior'),
(458, 81, '_wp_attachment_image_alt', 'Laura da Silva'),
(459, 82, '_wp_attachment_image_alt', 'André Augusto'),
(460, 83, '_wp_attachment_image_alt', 'Carol Santos'),
(461, 25, 'sobre_equipe_0_sub_foto', '80'),
(462, 25, '_sobre_equipe_0_sub_foto', 'field_6286fbef04288'),
(463, 25, 'sobre_equipe_0_sub_nome', 'Marcos Junior'),
(464, 25, '_sobre_equipe_0_sub_nome', 'field_6286fbe904287'),
(465, 25, 'sobre_equipe_0_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(466, 25, '_sobre_equipe_0_sub_texto', 'field_6286fc0804289'),
(467, 25, 'sobre_equipe_1_sub_foto', '81'),
(468, 25, '_sobre_equipe_1_sub_foto', 'field_6286fbef04288'),
(469, 25, 'sobre_equipe_1_sub_nome', 'Laura da Silva'),
(470, 25, '_sobre_equipe_1_sub_nome', 'field_6286fbe904287'),
(471, 25, 'sobre_equipe_1_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(472, 25, '_sobre_equipe_1_sub_texto', 'field_6286fc0804289'),
(473, 25, 'sobre_equipe_2_sub_foto', '82'),
(474, 25, '_sobre_equipe_2_sub_foto', 'field_6286fbef04288'),
(475, 25, 'sobre_equipe_2_sub_nome', 'André Augusto'),
(476, 25, '_sobre_equipe_2_sub_nome', 'field_6286fbe904287'),
(477, 25, 'sobre_equipe_2_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(478, 25, '_sobre_equipe_2_sub_texto', 'field_6286fc0804289'),
(479, 25, 'sobre_equipe_3_sub_foto', '83'),
(480, 25, '_sobre_equipe_3_sub_foto', 'field_6286fbef04288'),
(481, 25, 'sobre_equipe_3_sub_nome', 'Carol Santos'),
(482, 25, '_sobre_equipe_3_sub_nome', 'field_6286fbe904287'),
(483, 25, 'sobre_equipe_3_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(484, 25, '_sobre_equipe_3_sub_texto', 'field_6286fc0804289'),
(485, 84, 'capa_titulo', 'Law Firm'),
(486, 84, '_capa_titulo', 'field_6286fa7904274'),
(487, 84, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(488, 84, '_capa_texto', 'field_6286fa8204275'),
(489, 84, 'capa_link', 'http://localhost/incuca-tech/404'),
(490, 84, '_capa_link', 'field_6286fa8e04276'),
(491, 84, 'capa_img_desktop', '67'),
(492, 84, '_capa_img_desktop', 'field_6286fa9504277'),
(493, 84, 'capa_img_mobile', '68'),
(494, 84, '_capa_img_mobile', 'field_6286fabd04278'),
(495, 84, 'atuacao_titulo', 'Áreas de atuação'),
(496, 84, '_atuacao_titulo', 'field_6286faee0427a'),
(497, 84, 'atuacao_link', 'http://localhost/incuca-tech/404'),
(498, 84, '_atuacao_link', 'field_6286fafc0427b'),
(499, 84, 'atuacao_cards', '4'),
(500, 84, '_atuacao_cards', 'field_6286fb070427c'),
(501, 84, 'reflexao_texto', 'Não há um único dos nossos actos que, ao criarem o homem que queremos ser, não crie ao mesmo tempo uma imagem do homem tal como estimamos que ele deve ser.'),
(502, 84, '_reflexao_texto', 'field_6286fb7004281'),
(503, 84, 'reflexao_autor', 'Jean-Paul Sartre'),
(504, 84, '_reflexao_autor', 'field_6286fb7c04282'),
(505, 84, 'reflexao_img', '78'),
(506, 84, '_reflexao_img', 'field_6286fb8804283'),
(507, 84, 'sobre_titulo', 'Quem somos') ;
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(508, 84, '_sobre_titulo', 'field_6286fbb504285'),
(509, 84, 'sobre_equipe', '4'),
(510, 84, '_sobre_equipe', 'field_6286fbc404286'),
(511, 84, 'convite_titulo', ''),
(512, 84, '_convite_titulo', 'field_6286fc43c1002'),
(513, 84, 'convite_texto', ''),
(514, 84, '_convite_texto', 'field_6286fc4cc1003'),
(515, 84, 'convite_link', ''),
(516, 84, '_convite_link', 'field_6286fc5cc1004'),
(517, 84, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(518, 84, '_newsletter_texto', 'field_6286fcdba1a1b'),
(519, 84, 'atuacao_cards_0_sub_icone', '71'),
(520, 84, '_atuacao_cards_0_sub_icone', 'field_6286fb200427d'),
(521, 84, 'atuacao_cards_0_sub_titulo', 'Atuação 01'),
(522, 84, '_atuacao_cards_0_sub_titulo', 'field_6286fb330427e'),
(523, 84, 'atuacao_cards_0_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(524, 84, '_atuacao_cards_0_sub_texto', 'field_6286fb3a0427f'),
(525, 84, 'atuacao_cards_1_sub_icone', '72'),
(526, 84, '_atuacao_cards_1_sub_icone', 'field_6286fb200427d'),
(527, 84, 'atuacao_cards_1_sub_titulo', 'Atuação 02'),
(528, 84, '_atuacao_cards_1_sub_titulo', 'field_6286fb330427e'),
(529, 84, 'atuacao_cards_1_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(530, 84, '_atuacao_cards_1_sub_texto', 'field_6286fb3a0427f'),
(531, 84, 'atuacao_cards_2_sub_icone', '73'),
(532, 84, '_atuacao_cards_2_sub_icone', 'field_6286fb200427d'),
(533, 84, 'atuacao_cards_2_sub_titulo', 'Atuação 03'),
(534, 84, '_atuacao_cards_2_sub_titulo', 'field_6286fb330427e'),
(535, 84, 'atuacao_cards_2_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(536, 84, '_atuacao_cards_2_sub_texto', 'field_6286fb3a0427f'),
(537, 84, 'atuacao_cards_3_sub_icone', '74'),
(538, 84, '_atuacao_cards_3_sub_icone', 'field_6286fb200427d'),
(539, 84, 'atuacao_cards_3_sub_titulo', 'Atuação 04'),
(540, 84, '_atuacao_cards_3_sub_titulo', 'field_6286fb330427e'),
(541, 84, 'atuacao_cards_3_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(542, 84, '_atuacao_cards_3_sub_texto', 'field_6286fb3a0427f'),
(543, 84, 'sobre_equipe_0_sub_foto', '80'),
(544, 84, '_sobre_equipe_0_sub_foto', 'field_6286fbef04288'),
(545, 84, 'sobre_equipe_0_sub_nome', 'Marcos Junior'),
(546, 84, '_sobre_equipe_0_sub_nome', 'field_6286fbe904287'),
(547, 84, 'sobre_equipe_0_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(548, 84, '_sobre_equipe_0_sub_texto', 'field_6286fc0804289'),
(549, 84, 'sobre_equipe_1_sub_foto', '81'),
(550, 84, '_sobre_equipe_1_sub_foto', 'field_6286fbef04288'),
(551, 84, 'sobre_equipe_1_sub_nome', 'Laura da Silva'),
(552, 84, '_sobre_equipe_1_sub_nome', 'field_6286fbe904287'),
(553, 84, 'sobre_equipe_1_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(554, 84, '_sobre_equipe_1_sub_texto', 'field_6286fc0804289'),
(555, 84, 'sobre_equipe_2_sub_foto', '82'),
(556, 84, '_sobre_equipe_2_sub_foto', 'field_6286fbef04288'),
(557, 84, 'sobre_equipe_2_sub_nome', 'André Augusto'),
(558, 84, '_sobre_equipe_2_sub_nome', 'field_6286fbe904287'),
(559, 84, 'sobre_equipe_2_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(560, 84, '_sobre_equipe_2_sub_texto', 'field_6286fc0804289'),
(561, 84, 'sobre_equipe_3_sub_foto', '83'),
(562, 84, '_sobre_equipe_3_sub_foto', 'field_6286fbef04288'),
(563, 84, 'sobre_equipe_3_sub_nome', 'Carol Santos'),
(564, 84, '_sobre_equipe_3_sub_nome', 'field_6286fbe904287'),
(565, 84, 'sobre_equipe_3_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(566, 84, '_sobre_equipe_3_sub_texto', 'field_6286fc0804289'),
(567, 85, 'capa_titulo', 'Law Firm'),
(568, 85, '_capa_titulo', 'field_6286fa7904274'),
(569, 85, 'capa_texto', 'Os nossos conhecimentos são a reunião do raciocínio e experiência de numerosas mentes.'),
(570, 85, '_capa_texto', 'field_6286fa8204275'),
(571, 85, 'capa_link', 'http://localhost/incuca-tech/404'),
(572, 85, '_capa_link', 'field_6286fa8e04276'),
(573, 85, 'capa_img_desktop', '67'),
(574, 85, '_capa_img_desktop', 'field_6286fa9504277'),
(575, 85, 'capa_img_mobile', '68'),
(576, 85, '_capa_img_mobile', 'field_6286fabd04278'),
(577, 85, 'atuacao_titulo', 'Áreas de atuação'),
(578, 85, '_atuacao_titulo', 'field_6286faee0427a'),
(579, 85, 'atuacao_link', 'http://localhost/incuca-tech/404'),
(580, 85, '_atuacao_link', 'field_6286fafc0427b'),
(581, 85, 'atuacao_cards', '4'),
(582, 85, '_atuacao_cards', 'field_6286fb070427c'),
(583, 85, 'reflexao_texto', 'Não há um único dos nossos actos que, ao criarem o homem que queremos ser, não crie ao mesmo tempo uma imagem do homem tal como estimamos que ele deve ser.'),
(584, 85, '_reflexao_texto', 'field_6286fb7004281'),
(585, 85, 'reflexao_autor', 'Jean-Paul Sartre'),
(586, 85, '_reflexao_autor', 'field_6286fb7c04282'),
(587, 85, 'reflexao_img', '78'),
(588, 85, '_reflexao_img', 'field_6286fb8804283'),
(589, 85, 'sobre_titulo', 'Quem somos'),
(590, 85, '_sobre_titulo', 'field_6286fbb504285'),
(591, 85, 'sobre_equipe', '4'),
(592, 85, '_sobre_equipe', 'field_6286fbc404286'),
(593, 85, 'convite_titulo', 'Como a LAW FIRM pode te ajudar?'),
(594, 85, '_convite_titulo', 'field_6286fc43c1002'),
(595, 85, 'convite_texto', 'Duvidas sobre o seu caso? Entre em contato.\r\nCurabitur ac lacus sed turpis venenatis pharetra at.'),
(596, 85, '_convite_texto', 'field_6286fc4cc1003'),
(597, 85, 'convite_link', 'http://localhost/incuca-tech/404'),
(598, 85, '_convite_link', 'field_6286fc5cc1004'),
(599, 85, 'newsletter_texto', 'Receba artigos sobre velit in suscipit pharetra erat turpis tempor tortor'),
(600, 85, '_newsletter_texto', 'field_6286fcdba1a1b'),
(601, 85, 'atuacao_cards_0_sub_icone', '71'),
(602, 85, '_atuacao_cards_0_sub_icone', 'field_6286fb200427d'),
(603, 85, 'atuacao_cards_0_sub_titulo', 'Atuação 01'),
(604, 85, '_atuacao_cards_0_sub_titulo', 'field_6286fb330427e'),
(605, 85, 'atuacao_cards_0_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(606, 85, '_atuacao_cards_0_sub_texto', 'field_6286fb3a0427f'),
(607, 85, 'atuacao_cards_1_sub_icone', '72') ;
INSERT INTO `cuca_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(608, 85, '_atuacao_cards_1_sub_icone', 'field_6286fb200427d'),
(609, 85, 'atuacao_cards_1_sub_titulo', 'Atuação 02'),
(610, 85, '_atuacao_cards_1_sub_titulo', 'field_6286fb330427e'),
(611, 85, 'atuacao_cards_1_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(612, 85, '_atuacao_cards_1_sub_texto', 'field_6286fb3a0427f'),
(613, 85, 'atuacao_cards_2_sub_icone', '73'),
(614, 85, '_atuacao_cards_2_sub_icone', 'field_6286fb200427d'),
(615, 85, 'atuacao_cards_2_sub_titulo', 'Atuação 03'),
(616, 85, '_atuacao_cards_2_sub_titulo', 'field_6286fb330427e'),
(617, 85, 'atuacao_cards_2_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(618, 85, '_atuacao_cards_2_sub_texto', 'field_6286fb3a0427f'),
(619, 85, 'atuacao_cards_3_sub_icone', '74'),
(620, 85, '_atuacao_cards_3_sub_icone', 'field_6286fb200427d'),
(621, 85, 'atuacao_cards_3_sub_titulo', 'Atuação 04'),
(622, 85, '_atuacao_cards_3_sub_titulo', 'field_6286fb330427e'),
(623, 85, 'atuacao_cards_3_sub_texto', 'Nulla at porttitor sapien, id porttitor sapien. Pellentesque elementum dignissim velit vitae tincidunt.'),
(624, 85, '_atuacao_cards_3_sub_texto', 'field_6286fb3a0427f'),
(625, 85, 'sobre_equipe_0_sub_foto', '80'),
(626, 85, '_sobre_equipe_0_sub_foto', 'field_6286fbef04288'),
(627, 85, 'sobre_equipe_0_sub_nome', 'Marcos Junior'),
(628, 85, '_sobre_equipe_0_sub_nome', 'field_6286fbe904287'),
(629, 85, 'sobre_equipe_0_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(630, 85, '_sobre_equipe_0_sub_texto', 'field_6286fc0804289'),
(631, 85, 'sobre_equipe_1_sub_foto', '81'),
(632, 85, '_sobre_equipe_1_sub_foto', 'field_6286fbef04288'),
(633, 85, 'sobre_equipe_1_sub_nome', 'Laura da Silva'),
(634, 85, '_sobre_equipe_1_sub_nome', 'field_6286fbe904287'),
(635, 85, 'sobre_equipe_1_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(636, 85, '_sobre_equipe_1_sub_texto', 'field_6286fc0804289'),
(637, 85, 'sobre_equipe_2_sub_foto', '82'),
(638, 85, '_sobre_equipe_2_sub_foto', 'field_6286fbef04288'),
(639, 85, 'sobre_equipe_2_sub_nome', 'André Augusto'),
(640, 85, '_sobre_equipe_2_sub_nome', 'field_6286fbe904287'),
(641, 85, 'sobre_equipe_2_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(642, 85, '_sobre_equipe_2_sub_texto', 'field_6286fc0804289'),
(643, 85, 'sobre_equipe_3_sub_foto', '83'),
(644, 85, '_sobre_equipe_3_sub_foto', 'field_6286fbef04288'),
(645, 85, 'sobre_equipe_3_sub_nome', 'Carol Santos'),
(646, 85, '_sobre_equipe_3_sub_nome', 'field_6286fbe904287'),
(647, 85, 'sobre_equipe_3_sub_texto', 'Curabitur non laoreet ligula. Mauris pretium mauris diam, vel vehicula mauris tempus non. Aliquam finibus, massa tristique sagittis volutpat, lectus risus dignissim libero, id auctor erat ipsum nec orci.'),
(648, 85, '_sobre_equipe_3_sub_texto', 'field_6286fc0804289'),
(653, 88, '_wp_attached_file', '2022/05/post-1.png'),
(654, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:293;s:6:"height";i:175;s:4:"file";s:18:"2022/05/post-1.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(655, 88, '_wp_attachment_image_alt', 'Pessoas caminhando'),
(656, 87, '_edit_last', '1'),
(658, 87, '_yoast_wpseo_content_score', '30'),
(659, 87, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(660, 87, 'preview_foto', '88'),
(661, 87, '_preview_foto', 'field_6286fc9543f75'),
(662, 87, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(663, 87, '_preview_texto', 'field_6286fcaa43f76'),
(664, 89, 'preview_foto', '88'),
(665, 89, '_preview_foto', 'field_6286fc9543f75'),
(666, 89, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(667, 89, '_preview_texto', 'field_6286fcaa43f76'),
(668, 87, 'inline_featured_image', '0'),
(669, 87, '_edit_lock', '1653148757:1'),
(670, 90, '_edit_last', '1'),
(671, 90, '_edit_lock', '1653148749:1'),
(672, 91, '_wp_attached_file', '2022/05/post-2.png'),
(673, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:293;s:6:"height";i:175;s:4:"file";s:18:"2022/05/post-2.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(675, 90, '_yoast_wpseo_content_score', '30'),
(676, 90, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(677, 90, 'preview_foto', '91'),
(678, 90, '_preview_foto', 'field_6286fc9543f75'),
(679, 90, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(680, 90, '_preview_texto', 'field_6286fcaa43f76'),
(681, 92, 'preview_foto', '91'),
(682, 92, '_preview_foto', 'field_6286fc9543f75'),
(683, 92, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(684, 92, '_preview_texto', 'field_6286fcaa43f76'),
(685, 90, 'inline_featured_image', '0'),
(686, 93, '_edit_last', '1'),
(687, 93, '_edit_lock', '1653148875:1'),
(688, 94, '_wp_attached_file', '2022/05/post-3.png'),
(689, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:293;s:6:"height";i:175;s:4:"file";s:18:"2022/05/post-3.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(690, 91, '_wp_attachment_image_alt', 'Conjunto de prédios no por do sol'),
(691, 94, '_wp_attachment_image_alt', 'Pessoa olhando o relógio de pulso'),
(693, 93, '_yoast_wpseo_content_score', '30'),
(694, 93, '_yoast_wpseo_estimated-reading-time-minutes', ''),
(695, 93, 'preview_foto', '94'),
(696, 93, '_preview_foto', 'field_6286fc9543f75'),
(697, 93, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(698, 93, '_preview_texto', 'field_6286fcaa43f76'),
(699, 95, 'preview_foto', '91'),
(700, 95, '_preview_foto', 'field_6286fc9543f75'),
(701, 95, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(702, 95, '_preview_texto', 'field_6286fcaa43f76'),
(703, 93, 'inline_featured_image', '0'),
(705, 97, 'preview_foto', '94'),
(706, 97, '_preview_foto', 'field_6286fc9543f75'),
(707, 97, 'preview_texto', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut euismod imperdiet vulputate. Ut purus odio, pulvinar in augue id, auctor porta mi. Donec eget ligula id lectus placerat tempus ac ut metus. Phasellus congue arcu quis mauris eleifend imperdiet. Vivamus dolor purus, porta eget vestibulum ac, eleifend eu velit. Praesent nec ultricies ipsum, sed aliquam ex. Cras euismod pretium egestas. Aliquam erat volutpat.\r\n\r\nPellentesque eu nisi erat. Maecenas vel tincidunt nunc. Fusce risus dolor, rhoncus non tincidunt ac, vulputate ac risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ornare et quam vel porta. Donec nec elit ipsum. Duis ultricies vitae enim hendrerit tristique. Vivamus blandit lorem at facilisis tincidunt.\r\n\r\nNullam quis tellus luctus, elementum erat quis, sagittis nisl. Praesent vel felis ac orci condimentum tempus eget ac odio. Donec et dui lectus. Quisque et sapien rutrum, vulputate urna quis, aliquet diam. Sed suscipit condimentum sem, sed viverra nisl elementum at. Sed ornare risus in diam porttitor, sit amet ullamcorper magna tempor. Nulla ac lorem vehicula, mollis dolor eu, congue tellus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Etiam consectetur ligula fermentum lectus faucibus finibus. Phasellus nec pretium lacus.\r\n\r\nVestibulum non mauris lorem. Vestibulum id magna nec nunc dictum finibus vel vitae dolor. In bibendum at lorem eu porttitor. Proin euismod rutrum quam vel mollis. Etiam in ex aliquet, tempor erat eu, pellentesque magna. Donec a porttitor sapien, semper faucibus tortor. Integer rutrum porttitor facilisis. Integer eu laoreet ipsum. Suspendisse a lectus ut odio ultrices sollicitudin ut a lacus. Sed at cursus lacus, a mollis nibh. Pellentesque quis malesuada dui, sed sodales est. Nulla ac augue eros. Nulla orci eros, lobortis sed velit a, interdum sollicitudin sem. Morbi congue dignissim mi sit amet finibus.\r\n\r\nEtiam pretium malesuada magna rhoncus laoreet. Proin pellentesque bibendum condimentum. Sed sit amet velit accumsan, congue nisi a, pharetra justo. Nulla aliquam dui nec orci mattis, in convallis est fringilla. Maecenas efficitur lobortis massa vel viverra. Morbi maximus quam id dolor mattis semper. Nunc tincidunt pharetra nibh consequat mattis. Nulla quis dapibus turpis, at dapibus arcu. Cras dui lectus, pretium eu leo quis, consequat condimentum dui. Cras vel ex sit amet est pretium sodales non tincidunt ipsum. Sed porttitor sed risus eu molestie.'),
(708, 97, '_preview_texto', 'field_6286fcaa43f76') ;

#
# Fim do conteúdo da tabela `cuca_postmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_posts` existente
#

DROP TABLE IF EXISTS `cuca_posts`;


#
# Estrutura da tabela `cuca_posts`
#

CREATE TABLE `cuca_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_posts`
#
INSERT INTO `cuca_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(3, 1, '2022-05-19 22:49:21', '2022-05-20 01:49:21', '<!-- wp:heading -->\r\n<h2>Quem somos</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>O endereço do nosso site é: http://localhost/incuca-tech.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Comentários</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Quando os visitantes deixam comentários no site, coletamos os dados mostrados no formulário de comentários, além do endereço de IP e de dados do navegador do visitante, para auxiliar na detecção de spam.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Uma sequência anonimizada de caracteres criada a partir do seu e-mail (também chamada de hash) poderá ser enviada para o Gravatar para verificar se você usa o serviço. A política de privacidade do Gravatar está disponível aqui: https://automattic.com/privacy/. Depois da aprovação do seu comentário, a foto do seu perfil fica visível publicamente junto de seu comentário.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Mídia</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você envia imagens para o site, evite enviar as que contenham dados de localização incorporados (EXIF GPS). Visitantes podem baixar estas imagens do site e extrair delas seus dados de localização.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Cookies</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Ao deixar um comentário no site, você poderá optar por salvar seu nome, e-mail e site nos cookies. Isso visa seu conforto, assim você não precisará preencher seus dados novamente quando fizer outro comentário. Estes cookies duram um ano.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Se você tem uma conta e acessa este site, um cookie temporário será criado para determinar se seu navegador aceita cookies. Ele não contém nenhum dado pessoal e será descartado quando você fechar seu navegador.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Quando você acessa sua conta no site, também criamos vários cookies para salvar os dados da sua conta e suas escolhas de exibição de tela. Cookies de login são mantidos por dois dias e cookies de opções de tela por um ano. Se você selecionar "Lembrar-me", seu acesso será mantido por duas semanas. Se você se desconectar da sua conta, os cookies de login serão removidos.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Se você editar ou publicar um artigo, um cookie adicional será salvo no seu navegador. Este cookie não inclui nenhum dado pessoal e simplesmente indica o ID do post referente ao artigo que você acabou de editar. Ele expira depois de 1 dia.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Mídia incorporada de outros sites</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Artigos neste site podem incluir conteúdo incorporado como, por exemplo, vídeos, imagens, artigos, etc. Conteúdos incorporados de outros sites se comportam exatamente da mesma forma como se o visitante estivesse visitando o outro site.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Estes sites podem coletar dados sobre você, usar cookies, incorporar rastreamento adicional de terceiros e monitorar sua interação com este conteúdo incorporado, incluindo sua interação com o conteúdo incorporado se você tem uma conta e está conectado com o site.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Com quem compartilhamos seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você solicitar uma redefinição de senha, seu endereço de IP será incluído no e-mail de redefinição de senha.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Por quanto tempo mantemos os seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você deixar um comentário, o comentário e os seus metadados são conservados indefinidamente. Fazemos isso para que seja possível reconhecer e aprovar automaticamente qualquer comentário posterior ao invés de retê-lo para moderação.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Para usuários que se registram no nosso site (se houver), também guardamos as informações pessoais que fornecem no seu perfil de usuário. Todos os usuários podem ver, editar ou excluir suas informações pessoais a qualquer momento (só não é possível alterar o seu username). Os administradores de sites também podem ver e editar estas informações.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Quais os seus direitos sobre seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você tiver uma conta neste site ou se tiver deixado comentários, pode solicitar um arquivo exportado dos dados pessoais que mantemos sobre você, inclusive quaisquer dados que nos tenha fornecido. Também pode solicitar que removamos qualquer dado pessoal que mantemos sobre você. Isto não inclui nenhuns dados que somos obrigados a manter para propósitos administrativos, legais ou de segurança.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Para onde enviamos seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Comentários de visitantes podem ser marcados por um serviço automático de detecção de spam.</p>\r\n<!-- /wp:paragraph -->', 'Política de privacidade', '', 'publish', 'closed', 'open', '', 'politica-de-privacidade', '', '', '2022-05-19 23:29:08', '2022-05-20 02:29:08', '', 0, 'http://localhost/incuca-tech/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-05-19 22:49:37', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-05-19 22:49:37', '0000-00-00 00:00:00', '', 0, 'http://localhost/incuca-tech/?p=4', 0, 'post', '', 0),
(5, 1, '2022-05-19 23:02:03', '2022-05-20 02:02:03', '[text* nome placeholder akismet:author "Nome"]\r\n[email* email placeholder akismet:author_email "E-mail"]\r\n[text* telefone placeholder "Telefone"]\r\n[textarea* mensagem placeholder "Mensagem"]\r\n<button>Enviar</button>\n1\n[_site_title] "[your-subject]"\n[_site_title] <sites@gabrielfreelancer.com.br>\n[_site_admin_email]\nDe: [your-name] <[your-email]>\r\nAssunto: [your-subject]\r\n\r\nCorpo da mensagem:\r\n[your-message]\r\n\r\n-- \r\nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])\nReply-To: [your-email]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <sites@gabrielfreelancer.com.br>\n[your-email]\nCorpo da mensagem:\r\n[your-message]\r\n\r\n-- \r\nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nAgradecemos a sua mensagem.\nOcorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.\nUm ou mais campos possuem um erro. Verifique e tente novamente.\nOcorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.\nVocê deve aceitar os termos e condições antes de enviar sua mensagem.\nO campo é obrigatório.\nO campo é muito longo.\nO campo é muito curto.\nOcorreu um erro desconhecido ao enviar o arquivo.\nVocê não tem permissão para enviar esse tipo de arquivo.\nO arquivo é muito grande.\nOcorreu um erro ao enviar o arquivo.\nO formato de data está incorreto.\nA data é anterior à mais antiga permitida.\nA data é posterior à maior data permitida.\nO formato de número é inválido.\nO número é menor do que o mínimo permitido.\nO número é maior do que o máximo permitido.\nA resposta para o quiz está incorreta.\nO endereço de e-mail informado é inválido.\nA URL é inválida.\nO número de telefone é inválido.', 'Contato', '', 'publish', 'closed', 'closed', '', 'formulario-de-contato-1', '', '', '2022-05-21 00:13:22', '2022-05-21 03:13:22', '', 0, 'http://localhost/incuca-tech/?post_type=wpcf7_contact_form&#038;p=5', 0, 'wpcf7_contact_form', '', 0),
(6, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:13:"general-theme";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:15:"page_attributes";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Tema geral', 'tema-geral', 'publish', 'closed', 'closed', '', 'group_6286f7e72fd10', '', '', '2022-05-19 23:12:13', '2022-05-20 02:12:13', '', 0, 'http://localhost/incuca-tech/?post_type=acf-field-group&#038;p=6', 0, 'acf-field-group', '', 0),
(7, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Contato', 'contato', 'publish', 'closed', 'closed', '', 'field_6286f7f812b5b', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=7', 0, 'acf-field', '', 0),
(8, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:9:{s:4:"type";s:5:"email";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'E-mail', 'contato_email', 'publish', 'closed', 'closed', '', 'field_6286f85812b62', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=8', 1, 'acf-field', '', 0),
(9, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:16:"Número com DDD.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:14:"Adicionar mais";}', 'Telefone(s)', 'contato_telefone', 'publish', 'closed', 'closed', '', 'field_6286f7ff12b5c', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=9', 2, 'acf-field', '', 0),
(10, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Número', 'sub_numero', 'publish', 'closed', 'closed', '', 'field_6286f81912b5d', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 9, 'http://localhost/incuca-tech/?post_type=acf-field&p=10', 0, 'acf-field', '', 0),
(11, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:2;s:9:"new_lines";s:2:"br";}', 'Endereço', 'contato_endereco', 'publish', 'closed', 'closed', '', 'field_6286f86a12b63', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=11', 3, 'acf-field', '', 0),
(12, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:21:"Embed do Google Maps.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:3;s:9:"new_lines";s:0:"";}', 'Mapa', 'contato_mapa', 'publish', 'closed', 'closed', '', 'field_6286f89a12b65', '', '', '2022-05-19 23:12:13', '2022-05-20 02:12:13', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&#038;p=12', 4, 'acf-field', '', 0),
(13, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Redes sociais', 'contato_copiar', 'publish', 'closed', 'closed', '', 'field_6286f82812b5e', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=13', 5, 'acf-field', '', 0),
(14, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Facebook', 'social_facebook', 'publish', 'closed', 'closed', '', 'field_6286f82e12b5f', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=14', 6, 'acf-field', '', 0),
(15, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Twitter', 'social_twitter', 'publish', 'closed', 'closed', '', 'field_6286f83812b60', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=15', 7, 'acf-field', '', 0),
(16, 1, '2022-05-19 23:10:59', '2022-05-20 02:10:59', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Linkedin', 'social_linkedin', 'publish', 'closed', 'closed', '', 'field_6286f84112b61', '', '', '2022-05-19 23:10:59', '2022-05-20 02:10:59', '', 6, 'http://localhost/incuca-tech/?post_type=acf-field&p=16', 8, 'acf-field', '', 0),
(17, 1, '2022-05-19 23:11:33', '2022-05-20 02:11:33', '{{unknown}}', '', '', 'publish', 'closed', 'closed', '', '344d72fef52b83b894f7f0bc53e92d73', '', '', '2022-05-19 23:11:33', '2022-05-20 02:11:33', '', 0, 'http://localhost/incuca-tech/2022/05/19/344d72fef52b83b894f7f0bc53e92d73/', 0, 'oembed_cache', '', 0),
(18, 1, '2022-05-19 23:16:44', '2022-05-20 02:16:44', '{"blogname":{"value":"Law Firm","type":"option","user_id":1,"date_modified_gmt":"2022-05-20 02:15:21"},"blogdescription":{"value":"Reuni\\u00e3o de racioc\\u00ednio e experi\\u00eancia de numerosas mentes.","type":"option","user_id":1,"date_modified_gmt":"2022-05-20 02:15:21"},"site_icon":{"value":19,"type":"option","user_id":1,"date_modified_gmt":"2022-05-20 02:16:21"},"nav_menu[-5220315277948451000]":{"value":{"name":"Principal","description":"","parent":0,"auto_add":false},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-05-20 02:16:21"},"nav_menu_item[-1870195942139070500]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":1,"type":"custom","title":"Home","url":"#","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Home","nav_menu_term_id":-5220315277948451000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-05-20 02:16:21"},"nav_menu_item[-6085243438477316000]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":2,"type":"custom","title":"\\u00c1reas de atua\\u00e7\\u00e3o","url":"#","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"\\u00c1reas de atua\\u00e7\\u00e3o","nav_menu_term_id":-5220315277948451000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-05-20 02:16:44"},"nav_menu_item[-4763393468434504000]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":3,"type":"custom","title":"Equipe","url":"#","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Equipe","nav_menu_term_id":-5220315277948451000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-05-20 02:16:44"},"nav_menu_item[-406845860634519550]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":4,"type":"custom","title":"Artigos","url":"#","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Artigos","nav_menu_term_id":-5220315277948451000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-05-20 02:16:44"},"nav_menu_item[-4058876860068016000]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":5,"type":"custom","title":"Contato","url":"#","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Contato","nav_menu_term_id":-5220315277948451000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-05-20 02:16:44"}}', '', '', 'trash', 'closed', 'closed', '', '1686a5d1-19ff-42d0-a2cf-cd647f8c48f6', '', '', '2022-05-19 23:16:44', '2022-05-20 02:16:44', '', 0, 'http://localhost/incuca-tech/?p=18', 0, 'customize_changeset', '', 0),
(19, 1, '2022-05-19 23:15:39', '2022-05-20 02:15:39', '', '', '', 'inherit', 'open', 'closed', '', 'favicon-law-firm', '', '', '2022-05-19 23:15:51', '2022-05-20 02:15:51', '', 0, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/favicon-law-firm.png', 0, 'attachment', 'image/png', 0),
(20, 1, '2022-05-21 00:37:29', '2022-05-20 02:16:44', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-05-21 00:37:29', '2022-05-21 03:37:29', '', 0, 'http://localhost/incuca-tech/2022/05/19/home/', 1, 'nav_menu_item', '', 0),
(21, 1, '2022-05-21 00:37:29', '2022-05-20 02:16:44', '', 'Áreas de atuação', '', 'publish', 'closed', 'closed', '', 'areas-de-atuacao', '', '', '2022-05-21 00:37:29', '2022-05-21 03:37:29', '', 0, 'http://localhost/incuca-tech/2022/05/19/areas-de-atuacao/', 2, 'nav_menu_item', '', 0),
(22, 1, '2022-05-21 00:37:29', '2022-05-20 02:16:44', '', 'Equipe', '', 'publish', 'closed', 'closed', '', 'equipe', '', '', '2022-05-21 00:37:29', '2022-05-21 03:37:29', '', 0, 'http://localhost/incuca-tech/2022/05/19/equipe/', 3, 'nav_menu_item', '', 0),
(23, 1, '2022-05-21 00:37:29', '2022-05-20 02:16:44', '', 'Artigos', '', 'publish', 'closed', 'closed', '', 'artigos', '', '', '2022-05-21 00:37:29', '2022-05-21 03:37:29', '', 0, 'http://localhost/incuca-tech/2022/05/19/artigos/', 4, 'nav_menu_item', '', 0),
(24, 1, '2022-05-21 00:37:29', '2022-05-20 02:16:44', '', 'Contato', '', 'publish', 'closed', 'closed', '', 'contato', '', '', '2022-05-21 00:37:29', '2022-05-21 03:37:29', '', 0, 'http://localhost/incuca-tech/2022/05/19/contato/', 5, 'nav_menu_item', '', 0),
(25, 1, '2022-05-19 23:16:57', '2022-05-20 02:16:57', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-05-21 12:50:18', '2022-05-21 15:50:18', '', 0, 'http://localhost/incuca-tech/?page_id=25', 0, 'page', '', 0),
(26, 1, '2022-05-19 23:16:57', '2022-05-20 02:16:57', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-19 23:16:57', '2022-05-20 02:16:57', '', 25, 'http://localhost/incuca-tech/?p=26', 0, 'revision', '', 0),
(27, 1, '2022-05-19 23:17:04', '2022-05-20 02:17:04', '{"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2022-05-20 02:17:04"}}', '', '', 'trash', 'closed', 'closed', '', '863dcece-d03d-49e5-a720-421bd56376fb', '', '', '2022-05-19 23:17:04', '2022-05-20 02:17:04', '', 0, 'http://localhost/incuca-tech/2022/05/19/863dcece-d03d-49e5-a720-421bd56376fb/', 0, 'customize_changeset', '', 0),
(28, 1, '2022-05-19 23:17:14', '2022-05-20 02:17:14', '{"page_on_front":{"value":"25","type":"option","user_id":1,"date_modified_gmt":"2022-05-20 02:17:14"}}', '', '', 'trash', 'closed', 'closed', '', 'e7838314-e140-4269-9de1-058566dd67f1', '', '', '2022-05-19 23:17:14', '2022-05-20 02:17:14', '', 0, 'http://localhost/incuca-tech/2022/05/19/e7838314-e140-4269-9de1-058566dd67f1/', 0, 'customize_changeset', '', 0),
(30, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"page_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"front_page";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:12:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:10:"discussion";i:3;s:8:"comments";i:4;s:9:"revisions";i:5;s:4:"slug";i:6;s:6:"author";i:7;s:6:"format";i:8;s:14:"featured_image";i:9;s:10:"categories";i:10;s:4:"tags";i:11;s:15:"send-trackbacks";}s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Página home', 'pagina-home', 'publish', 'closed', 'closed', '', 'group_6286fa551dfdc', '', '', '2022-05-21 12:52:47', '2022-05-21 15:52:47', '', 0, 'http://localhost/incuca-tech/?post_type=acf-field-group&#038;p=30', 0, 'acf-field-group', '', 0),
(31, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Capa', 'capa', 'publish', 'closed', 'closed', '', 'field_6286fa6704273', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=31', 0, 'acf-field', '', 0),
(32, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'capa_titulo', 'publish', 'closed', 'closed', '', 'field_6286fa7904274', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=32', 1, 'acf-field', '', 0),
(33, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Texto', 'capa_texto', 'publish', 'closed', 'closed', '', 'field_6286fa8204275', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=33', 2, 'acf-field', '', 0),
(34, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link', 'capa_link', 'publish', 'closed', 'closed', '', 'field_6286fa8e04276', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=34', 3, 'acf-field', '', 0),
(35, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:10:"Até 1 MB.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:1;s:10:"mime_types";s:0:"";}', 'Imagem desktop', 'capa_img_desktop', 'publish', 'closed', 'closed', '', 'field_6286fa9504277', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=35', 4, 'acf-field', '', 0),
(36, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:10:"Até 1 MB.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:1;s:10:"mime_types";s:0:"";}', 'Imagem mobile', 'capa_img_mobile', 'publish', 'closed', 'closed', '', 'field_6286fabd04278', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=36', 5, 'acf-field', '', 0),
(37, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Área de atuação', 'capa_copiar', 'publish', 'closed', 'closed', '', 'field_6286fadf04279', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=37', 6, 'acf-field', '', 0),
(38, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'atuacao_titulo', 'publish', 'closed', 'closed', '', 'field_6286faee0427a', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=38', 7, 'acf-field', '', 0),
(39, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link', 'atuacao_link', 'publish', 'closed', 'closed', '', 'field_6286fafc0427b', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=39', 8, 'acf-field', '', 0),
(40, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:22:"Imagens com até 1 MB.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:14:"Adicionar mais";}', 'Cards', 'atuacao_cards', 'publish', 'closed', 'closed', '', 'field_6286fb070427c', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=40', 9, 'acf-field', '', 0),
(41, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:1;s:10:"mime_types";s:0:"";}', 'Ícone', 'sub_icone', 'publish', 'closed', 'closed', '', 'field_6286fb200427d', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 40, 'http://localhost/incuca-tech/?post_type=acf-field&p=41', 0, 'acf-field', '', 0),
(42, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'sub_titulo', 'publish', 'closed', 'closed', '', 'field_6286fb330427e', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 40, 'http://localhost/incuca-tech/?post_type=acf-field&p=42', 1, 'acf-field', '', 0),
(43, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Texto', 'sub_texto', 'publish', 'closed', 'closed', '', 'field_6286fb3a0427f', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 40, 'http://localhost/incuca-tech/?post_type=acf-field&p=43', 2, 'acf-field', '', 0),
(44, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Reflexão', 'capa_copiar2', 'publish', 'closed', 'closed', '', 'field_6286fb5304280', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=44', 10, 'acf-field', '', 0),
(45, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Texto', 'reflexao_texto', 'publish', 'closed', 'closed', '', 'field_6286fb7004281', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=45', 11, 'acf-field', '', 0),
(46, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Autor', 'reflexao_autor', 'publish', 'closed', 'closed', '', 'field_6286fb7c04282', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=46', 12, 'acf-field', '', 0),
(47, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:10:"Até 1 MB.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:1;s:10:"mime_types";s:0:"";}', 'Imagem', 'reflexao_img', 'publish', 'closed', 'closed', '', 'field_6286fb8804283', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=47', 13, 'acf-field', '', 0),
(48, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Sobre', 'capa_copiar3', 'publish', 'closed', 'closed', '', 'field_6286fbae04284', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=48', 14, 'acf-field', '', 0),
(49, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'sobre_titulo', 'publish', 'closed', 'closed', '', 'field_6286fbb504285', '', '', '2022-05-19 23:26:49', '2022-05-20 02:26:49', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&#038;p=49', 15, 'acf-field', '', 0),
(50, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:22:"Imagens com até 1 MB.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";i:4;s:6:"layout";s:3:"row";s:12:"button_label";s:14:"Adicionar mais";}', 'Equipe', 'sobre_equipe', 'publish', 'closed', 'closed', '', 'field_6286fbc404286', '', '', '2022-05-21 12:45:20', '2022-05-21 15:45:20', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&#038;p=50', 16, 'acf-field', '', 0),
(51, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:1;s:10:"mime_types";s:0:"";}', 'Foto', 'sub_foto', 'publish', 'closed', 'closed', '', 'field_6286fbef04288', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 50, 'http://localhost/incuca-tech/?post_type=acf-field&p=51', 0, 'acf-field', '', 0),
(52, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Nome', 'sub_nome', 'publish', 'closed', 'closed', '', 'field_6286fbe904287', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 50, 'http://localhost/incuca-tech/?post_type=acf-field&p=52', 1, 'acf-field', '', 0),
(53, 1, '2022-05-19 23:25:35', '2022-05-20 02:25:35', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:2;s:9:"new_lines";s:0:"";}', 'Texto', 'sub_texto', 'publish', 'closed', 'closed', '', 'field_6286fc0804289', '', '', '2022-05-19 23:25:35', '2022-05-20 02:25:35', '', 50, 'http://localhost/incuca-tech/?post_type=acf-field&p=53', 2, 'acf-field', '', 0),
(54, 1, '2022-05-19 23:26:49', '2022-05-20 02:26:49', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Convite', '_copiar', 'publish', 'closed', 'closed', '', 'field_6286fc37c1001', '', '', '2022-05-19 23:26:49', '2022-05-20 02:26:49', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=54', 17, 'acf-field', '', 0),
(55, 1, '2022-05-19 23:26:49', '2022-05-20 02:26:49', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'convite_titulo', 'publish', 'closed', 'closed', '', 'field_6286fc43c1002', '', '', '2022-05-19 23:28:59', '2022-05-20 02:28:59', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&#038;p=55', 18, 'acf-field', '', 0),
(56, 1, '2022-05-19 23:26:49', '2022-05-20 02:26:49', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:3;s:9:"new_lines";s:2:"br";}', 'Texto', 'convite_texto', 'publish', 'closed', 'closed', '', 'field_6286fc4cc1003', '', '', '2022-05-21 12:52:47', '2022-05-21 15:52:47', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&#038;p=56', 19, 'acf-field', '', 0),
(57, 1, '2022-05-19 23:26:49', '2022-05-20 02:26:49', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link', 'convite_link', 'publish', 'closed', 'closed', '', 'field_6286fc5cc1004', '', '', '2022-05-19 23:28:59', '2022-05-20 02:28:59', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&#038;p=57', 20, 'acf-field', '', 0),
(58, 1, '2022-05-19 23:28:14', '2022-05-20 02:28:14', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:13:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:10:"discussion";i:3;s:8:"comments";i:4;s:9:"revisions";i:5;s:4:"slug";i:6;s:6:"author";i:7;s:6:"format";i:8;s:15:"page_attributes";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', '[CPT] Artigo', 'cpt-artigo', 'publish', 'closed', 'closed', '', 'group_6286fc6f4735d', '', '', '2022-05-19 23:28:14', '2022-05-20 02:28:14', '', 0, 'http://localhost/incuca-tech/?post_type=acf-field-group&#038;p=58', 0, 'acf-field-group', '', 0),
(59, 1, '2022-05-19 23:28:14', '2022-05-20 02:28:14', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Pré-visualização', 'pre-visualizacao', 'publish', 'closed', 'closed', '', 'field_6286fc7f43f74', '', '', '2022-05-19 23:28:14', '2022-05-20 02:28:14', '', 58, 'http://localhost/incuca-tech/?post_type=acf-field&p=59', 0, 'acf-field', '', 0),
(60, 1, '2022-05-19 23:28:14', '2022-05-20 02:28:14', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:10:"Até 1 MB.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";i:1;s:10:"mime_types";s:0:"";}', 'Foto', 'preview_foto', 'publish', 'closed', 'closed', '', 'field_6286fc9543f75', '', '', '2022-05-19 23:28:14', '2022-05-20 02:28:14', '', 58, 'http://localhost/incuca-tech/?post_type=acf-field&p=60', 1, 'acf-field', '', 0),
(61, 1, '2022-05-19 23:28:14', '2022-05-20 02:28:14', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;s:5:"delay";i:0;}', 'Texto', 'preview_texto', 'publish', 'closed', 'closed', '', 'field_6286fcaa43f76', '', '', '2022-05-19 23:28:14', '2022-05-20 02:28:14', '', 58, 'http://localhost/incuca-tech/?post_type=acf-field&p=61', 2, 'acf-field', '', 0),
(62, 1, '2022-05-19 23:28:59', '2022-05-20 02:28:59', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Newsletter', '_copiar', 'publish', 'closed', 'closed', '', 'field_6286fcd3a1a1a', '', '', '2022-05-19 23:28:59', '2022-05-20 02:28:59', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=62', 21, 'acf-field', '', 0),
(63, 1, '2022-05-19 23:28:59', '2022-05-20 02:28:59', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Texto', 'newsletter_texto', 'publish', 'closed', 'closed', '', 'field_6286fcdba1a1b', '', '', '2022-05-19 23:28:59', '2022-05-20 02:28:59', '', 30, 'http://localhost/incuca-tech/?post_type=acf-field&p=63', 22, 'acf-field', '', 0),
(64, 1, '2022-05-19 23:29:08', '2022-05-20 02:29:08', '<!-- wp:heading -->\r\n<h2>Quem somos</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>O endereço do nosso site é: http://localhost/incuca-tech.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Comentários</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Quando os visitantes deixam comentários no site, coletamos os dados mostrados no formulário de comentários, além do endereço de IP e de dados do navegador do visitante, para auxiliar na detecção de spam.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Uma sequência anonimizada de caracteres criada a partir do seu e-mail (também chamada de hash) poderá ser enviada para o Gravatar para verificar se você usa o serviço. A política de privacidade do Gravatar está disponível aqui: https://automattic.com/privacy/. Depois da aprovação do seu comentário, a foto do seu perfil fica visível publicamente junto de seu comentário.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Mídia</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você envia imagens para o site, evite enviar as que contenham dados de localização incorporados (EXIF GPS). Visitantes podem baixar estas imagens do site e extrair delas seus dados de localização.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Cookies</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Ao deixar um comentário no site, você poderá optar por salvar seu nome, e-mail e site nos cookies. Isso visa seu conforto, assim você não precisará preencher seus dados novamente quando fizer outro comentário. Estes cookies duram um ano.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Se você tem uma conta e acessa este site, um cookie temporário será criado para determinar se seu navegador aceita cookies. Ele não contém nenhum dado pessoal e será descartado quando você fechar seu navegador.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Quando você acessa sua conta no site, também criamos vários cookies para salvar os dados da sua conta e suas escolhas de exibição de tela. Cookies de login são mantidos por dois dias e cookies de opções de tela por um ano. Se você selecionar "Lembrar-me", seu acesso será mantido por duas semanas. Se você se desconectar da sua conta, os cookies de login serão removidos.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Se você editar ou publicar um artigo, um cookie adicional será salvo no seu navegador. Este cookie não inclui nenhum dado pessoal e simplesmente indica o ID do post referente ao artigo que você acabou de editar. Ele expira depois de 1 dia.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Mídia incorporada de outros sites</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Artigos neste site podem incluir conteúdo incorporado como, por exemplo, vídeos, imagens, artigos, etc. Conteúdos incorporados de outros sites se comportam exatamente da mesma forma como se o visitante estivesse visitando o outro site.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Estes sites podem coletar dados sobre você, usar cookies, incorporar rastreamento adicional de terceiros e monitorar sua interação com este conteúdo incorporado, incluindo sua interação com o conteúdo incorporado se você tem uma conta e está conectado com o site.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Com quem compartilhamos seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você solicitar uma redefinição de senha, seu endereço de IP será incluído no e-mail de redefinição de senha.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Por quanto tempo mantemos os seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você deixar um comentário, o comentário e os seus metadados são conservados indefinidamente. Fazemos isso para que seja possível reconhecer e aprovar automaticamente qualquer comentário posterior ao invés de retê-lo para moderação.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Para usuários que se registram no nosso site (se houver), também guardamos as informações pessoais que fornecem no seu perfil de usuário. Todos os usuários podem ver, editar ou excluir suas informações pessoais a qualquer momento (só não é possível alterar o seu username). Os administradores de sites também podem ver e editar estas informações.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Quais os seus direitos sobre seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você tiver uma conta neste site ou se tiver deixado comentários, pode solicitar um arquivo exportado dos dados pessoais que mantemos sobre você, inclusive quaisquer dados que nos tenha fornecido. Também pode solicitar que removamos qualquer dado pessoal que mantemos sobre você. Isto não inclui nenhuns dados que somos obrigados a manter para propósitos administrativos, legais ou de segurança.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Para onde enviamos seus dados</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Comentários de visitantes podem ser marcados por um serviço automático de detecção de spam.</p>\r\n<!-- /wp:paragraph -->', 'Política de privacidade', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2022-05-19 23:29:08', '2022-05-20 02:29:08', '', 3, 'http://localhost/incuca-tech/?p=64', 0, 'revision', '', 0) ;
INSERT INTO `cuca_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(65, 1, '2022-05-21 00:27:24', '2022-05-21 03:27:24', '[email* email placeholder akismet:author_email "Digite o seu e-mail"]<button>Enviar</button>\n1\n[_site_title] "[your-subject]"\n[_site_title] <sites@gabrielfreelancer.com.br>\n[_site_admin_email]\nDe: [your-name] <[your-email]>\r\nAssunto: [your-subject]\r\n\r\nCorpo da mensagem:\r\n[your-message]\r\n\r\n-- \r\nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])\nReply-To: [your-email]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <sites@gabrielfreelancer.com.br>\n[your-email]\nCorpo da mensagem:\r\n[your-message]\r\n\r\n-- \r\nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nAgradecemos a sua mensagem.\nOcorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.\nUm ou mais campos possuem um erro. Verifique e tente novamente.\nOcorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.\nVocê deve aceitar os termos e condições antes de enviar sua mensagem.\nO campo é obrigatório.\nO campo é muito longo.\nO campo é muito curto.\nOcorreu um erro desconhecido ao enviar o arquivo.\nVocê não tem permissão para enviar esse tipo de arquivo.\nO arquivo é muito grande.\nOcorreu um erro ao enviar o arquivo.\nO formato de data está incorreto.\nA data é anterior à mais antiga permitida.\nA data é posterior à maior data permitida.\nO formato de número é inválido.\nO número é menor do que o mínimo permitido.\nO número é maior do que o máximo permitido.\nA resposta para o quiz está incorreta.\nO endereço de e-mail informado é inválido.\nA URL é inválida.\nO número de telefone é inválido.', 'Newsletter', '', 'publish', 'closed', 'closed', '', 'newsletter', '', '', '2022-05-21 00:27:24', '2022-05-21 03:27:24', '', 0, 'http://localhost/incuca-tech/?post_type=wpcf7_contact_form&p=65', 0, 'wpcf7_contact_form', '', 0),
(66, 1, '2022-05-21 00:29:23', '2022-05-21 03:29:23', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 00:29:23', '2022-05-21 03:29:23', '', 25, 'http://localhost/incuca-tech/?p=66', 0, 'revision', '', 0),
(67, 1, '2022-05-21 11:07:02', '2022-05-21 14:07:02', '', '', '', 'inherit', 'open', 'closed', '', 'hero-desktop', '', '', '2022-05-21 11:37:49', '2022-05-21 14:37:49', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-desktop.png', 0, 'attachment', 'image/png', 0),
(68, 1, '2022-05-21 11:07:10', '2022-05-21 14:07:10', '', '', '', 'inherit', 'open', 'closed', '', 'hero-mobile', '', '', '2022-05-21 11:37:40', '2022-05-21 14:37:40', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-mobile.png', 0, 'attachment', 'image/png', 0),
(69, 1, '2022-05-21 11:07:16', '2022-05-21 14:07:16', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 11:07:16', '2022-05-21 14:07:16', '', 25, 'http://localhost/incuca-tech/?p=69', 0, 'revision', '', 0),
(70, 1, '2022-05-21 11:31:12', '2022-05-21 14:31:12', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 11:31:12', '2022-05-21 14:31:12', '', 25, 'http://localhost/incuca-tech/?p=70', 0, 'revision', '', 0),
(71, 1, '2022-05-21 11:36:41', '2022-05-21 14:36:41', '', '', '', 'inherit', 'open', 'closed', '', 'atuacao-01', '', '', '2022-05-21 11:37:17', '2022-05-21 14:37:17', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-01.png', 0, 'attachment', 'image/png', 0),
(72, 1, '2022-05-21 11:36:51', '2022-05-21 14:36:51', '', '', '', 'inherit', 'open', 'closed', '', 'atuacao-02', '', '', '2022-05-21 11:37:21', '2022-05-21 14:37:21', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-02.png', 0, 'attachment', 'image/png', 0),
(73, 1, '2022-05-21 11:36:57', '2022-05-21 14:36:57', '', '', '', 'inherit', 'open', 'closed', '', 'atuacao-03', '', '', '2022-05-21 11:37:25', '2022-05-21 14:37:25', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-03.png', 0, 'attachment', 'image/png', 0),
(74, 1, '2022-05-21 11:37:04', '2022-05-21 14:37:04', '', '', '', 'inherit', 'open', 'closed', '', 'atuacao-04', '', '', '2022-05-21 11:37:30', '2022-05-21 14:37:30', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-04.png', 0, 'attachment', 'image/png', 0),
(75, 1, '2022-05-21 11:37:54', '2022-05-21 14:37:54', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 11:37:54', '2022-05-21 14:37:54', '', 25, 'http://localhost/incuca-tech/?p=75', 0, 'revision', '', 0),
(77, 1, '2022-05-21 11:49:06', '2022-05-21 14:49:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 11:49:06', '2022-05-21 14:49:06', '', 25, 'http://localhost/incuca-tech/?p=77', 0, 'revision', '', 0),
(78, 1, '2022-05-21 11:57:14', '2022-05-21 14:57:14', '', '', '', 'inherit', 'open', 'closed', '', 'reflexxao', '', '', '2022-05-21 11:57:45', '2022-05-21 14:57:45', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/reflexxao.png', 0, 'attachment', 'image/png', 0),
(79, 1, '2022-05-21 11:57:50', '2022-05-21 14:57:50', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 11:57:50', '2022-05-21 14:57:50', '', 25, 'http://localhost/incuca-tech/?p=79', 0, 'revision', '', 0),
(80, 1, '2022-05-21 12:12:03', '2022-05-21 15:12:03', '', '', '', 'inherit', 'open', 'closed', '', 'marcos-junior', '', '', '2022-05-21 12:12:21', '2022-05-21 15:12:21', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/marcos-junior.png', 0, 'attachment', 'image/png', 0),
(81, 1, '2022-05-21 12:12:03', '2022-05-21 15:12:03', '', '', '', 'inherit', 'open', 'closed', '', 'laura-da-silva', '', '', '2022-05-21 12:12:28', '2022-05-21 15:12:28', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/laura-da-silva.png', 0, 'attachment', 'image/png', 0),
(82, 1, '2022-05-21 12:12:04', '2022-05-21 15:12:04', '', '', '', 'inherit', 'open', 'closed', '', 'andre-augusto', '', '', '2022-05-21 12:12:37', '2022-05-21 15:12:37', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/andre-augusto.png', 0, 'attachment', 'image/png', 0),
(83, 1, '2022-05-21 12:12:05', '2022-05-21 15:12:05', '', '', '', 'inherit', 'open', 'closed', '', 'carol-santos', '', '', '2022-05-21 12:12:54', '2022-05-21 15:12:54', '', 25, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/carol-santos.png', 0, 'attachment', 'image/png', 0),
(84, 1, '2022-05-21 12:13:28', '2022-05-21 15:13:28', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 12:13:28', '2022-05-21 15:13:28', '', 25, 'http://localhost/incuca-tech/?p=84', 0, 'revision', '', 0),
(85, 1, '2022-05-21 12:50:18', '2022-05-21 15:50:18', '', 'Home', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2022-05-21 12:50:18', '2022-05-21 15:50:18', '', 25, 'http://localhost/incuca-tech/?p=85', 0, 'revision', '', 0),
(87, 1, '2022-05-21 13:00:28', '2022-05-21 16:00:28', '', 'Vestibulum fringilla semper quam non sodales.', '', 'publish', 'open', 'open', '', 'vestibulum-fringilla-semper-quam-non-sodales', '', '', '2022-05-21 13:00:28', '2022-05-21 16:00:28', '', 0, 'http://localhost/incuca-tech/?p=87', 0, 'post', '', 0),
(88, 1, '2022-05-21 13:00:16', '2022-05-21 16:00:16', '', '', '', 'inherit', 'open', 'closed', '', 'post-1', '', '', '2022-05-21 13:00:24', '2022-05-21 16:00:24', '', 87, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-1.png', 0, 'attachment', 'image/png', 0),
(89, 1, '2022-05-21 13:00:28', '2022-05-21 16:00:28', '', 'Vestibulum fringilla semper quam non sodales.', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2022-05-21 13:00:28', '2022-05-21 16:00:28', '', 87, 'http://localhost/incuca-tech/?p=89', 0, 'revision', '', 0),
(90, 1, '2022-05-21 13:01:29', '2022-05-21 16:01:29', '', 'Sed ornare euismod ex, nec aliquam lorem fringilla sed.', '', 'publish', 'open', 'open', '', 'sed-ornare-euismod-ex-nec-aliquam-lorem-fringilla-sed', '', '', '2022-05-21 13:01:29', '2022-05-21 16:01:29', '', 0, 'http://localhost/incuca-tech/?p=90', 0, 'post', '', 0),
(91, 1, '2022-05-21 13:01:23', '2022-05-21 16:01:23', '', '', '', 'inherit', 'open', 'closed', '', 'post-2', '', '', '2022-05-21 13:02:12', '2022-05-21 16:02:12', '', 90, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-2.png', 0, 'attachment', 'image/png', 0),
(92, 1, '2022-05-21 13:01:29', '2022-05-21 16:01:29', '', 'Sed ornare euismod ex, nec aliquam lorem fringilla sed.', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2022-05-21 13:01:29', '2022-05-21 16:01:29', '', 90, 'http://localhost/incuca-tech/?p=92', 0, 'revision', '', 0),
(93, 1, '2022-05-21 13:02:45', '2022-05-21 16:02:45', '', 'Usce vulputate ligula quis enim fringilla, nec placerat nisl porta.', '', 'publish', 'open', 'open', '', 'usce-vulputate-ligula-quis-enim-fringilla-nec-placerat-nisl-porta', '', '', '2022-05-21 13:02:59', '2022-05-21 16:02:59', '', 0, 'http://localhost/incuca-tech/?p=93', 0, 'post', '', 0),
(94, 1, '2022-05-21 13:01:47', '2022-05-21 16:01:47', '', '', '', 'inherit', 'open', 'closed', '', 'post-3', '', '', '2022-05-21 13:02:38', '2022-05-21 16:02:38', '', 93, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-3.png', 0, 'attachment', 'image/png', 0),
(95, 1, '2022-05-21 13:02:45', '2022-05-21 16:02:45', '', 'Usce vulputate ligula quis enim fringilla, nec placerat nisl porta.', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-05-21 13:02:45', '2022-05-21 16:02:45', '', 93, 'http://localhost/incuca-tech/?p=95', 0, 'revision', '', 0),
(97, 1, '2022-05-21 13:02:59', '2022-05-21 16:02:59', '', 'Usce vulputate ligula quis enim fringilla, nec placerat nisl porta.', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-05-21 13:02:59', '2022-05-21 16:02:59', '', 93, 'http://localhost/incuca-tech/?p=97', 0, 'revision', '', 0) ;

#
# Fim do conteúdo da tabela `cuca_posts`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_term_relationships` existente
#

DROP TABLE IF EXISTS `cuca_term_relationships`;


#
# Estrutura da tabela `cuca_term_relationships`
#

CREATE TABLE `cuca_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_term_relationships`
#
INSERT INTO `cuca_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(87, 1, 0),
(90, 1, 0),
(93, 1, 0) ;

#
# Fim do conteúdo da tabela `cuca_term_relationships`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_term_taxonomy` existente
#

DROP TABLE IF EXISTS `cuca_term_taxonomy`;


#
# Estrutura da tabela `cuca_term_taxonomy`
#

CREATE TABLE `cuca_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_term_taxonomy`
#
INSERT INTO `cuca_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'nav_menu', '', 0, 5) ;

#
# Fim do conteúdo da tabela `cuca_term_taxonomy`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_termmeta` existente
#

DROP TABLE IF EXISTS `cuca_termmeta`;


#
# Estrutura da tabela `cuca_termmeta`
#

CREATE TABLE `cuca_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_termmeta`
#

#
# Fim do conteúdo da tabela `cuca_termmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_terms` existente
#

DROP TABLE IF EXISTS `cuca_terms`;


#
# Estrutura da tabela `cuca_terms`
#

CREATE TABLE `cuca_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_terms`
#
INSERT INTO `cuca_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sem categoria', 'sem-categoria', 0),
(2, 'Principal', 'principal', 0) ;

#
# Fim do conteúdo da tabela `cuca_terms`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_usermeta` existente
#

DROP TABLE IF EXISTS `cuca_usermeta`;


#
# Estrutura da tabela `cuca_usermeta`
#

CREATE TABLE `cuca_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_usermeta`
#
INSERT INTO `cuca_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'amarante'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'cuca_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'cuca_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:3:{s:64:"5d3ed710e1690246fc326701ee5295374d46047a5dee47cf0c2d5e0733d5b69e";a:4:{s:10:"expiration";i:1653184174;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36";s:5:"login";i:1653011374;}s:64:"84176c7aa23348b00026ff17d699eeb32ad483848f74c90dd42f4fd8193affcb";a:4:{s:10:"expiration";i:1653264861;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36";s:5:"login";i:1653092061;}s:64:"5876e1a121f0090f2e96afee7043cde97e236789fdd8520fd85e95f16ca34476";a:4:{s:10:"expiration";i:1653314609;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36";s:5:"login";i:1653141809;}}'),
(17, 1, 'cuca_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'cuca_yoast_notifications', 'a:1:{i:0;a:2:{s:7:"message";s:396:"<p>Você pode acelerar seu site e obter informações sobre sua estrutura de links internos, permitindo que façamos algumas otimizações na forma como os dados de SEO são armazenados.</p><p>Estimamos que isso levará menos de um minuto.</p><a class="button" href="http://localhost/incuca-tech/wp-admin/admin.php?page=wpseo_tools&start-indexation=true">Comece a otimização de dados de SEO</a>";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:13:"wpseo-reindex";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:8:"amarante";s:9:"user_pass";s:34:"$P$BEPrVoLWfAoiDZY8oH4EreddlOYsl41";s:13:"user_nicename";s:8:"amarante";s:10:"user_email";s:30:"sites@gabrielfreelancer.com.br";s:8:"user_url";s:28:"http://localhost/incuca-tech";s:15:"user_registered";s:19:"2022-05-20 01:49:21";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:8:"amarante";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:17:"cuca_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}'),
(19, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(20, 1, 'metaboxhidden_dashboard', 'a:6:{i:0;s:21:"dashboard_site_health";i:1;s:19:"dashboard_right_now";i:2;s:18:"dashboard_activity";i:3;s:24:"wpseo-dashboard-overview";i:4;s:21:"dashboard_quick_press";i:5;s:17:"dashboard_primary";}'),
(21, 1, '_yoast_wpseo_profile_updated', '1653012418'),
(22, 1, 'cuca_user-settings', 'libraryContent=browse'),
(23, 1, 'cuca_user-settings-time', '1653013007'),
(24, 1, 'ame_rui_first_login_done', '1'),
(25, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:3:"5.5";}'),
(26, 1, 'nav_menu_recently_edited', '2'),
(27, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(28, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}') ;

#
# Fim do conteúdo da tabela `cuca_usermeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_users` existente
#

DROP TABLE IF EXISTS `cuca_users`;


#
# Estrutura da tabela `cuca_users`
#

CREATE TABLE `cuca_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_users`
#
INSERT INTO `cuca_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'amarante', '$P$BEPrVoLWfAoiDZY8oH4EreddlOYsl41', 'amarante', 'sites@gabrielfreelancer.com.br', 'http://localhost/incuca-tech', '2022-05-20 01:49:21', '', 0, 'amarante') ;

#
# Fim do conteúdo da tabela `cuca_users`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_yoast_indexable` existente
#

DROP TABLE IF EXISTS `cuca_yoast_indexable`;


#
# Estrutura da tabela `cuca_yoast_indexable`
#

CREATE TABLE `cuca_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  `language` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_yoast_indexable`
#
INSERT INTO `cuca_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'http://localhost/incuca-tech/author/amarante/', '45:af35101ccf8aea77e749d59ebb5bf755', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://1.gravatar.com/avatar/de3b60fd3520e95745b280d7bdfc770e?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://1.gravatar.com/avatar/de3b60fd3520e95745b280d7bdfc770e?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 16:02:59', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 16:02:59', '2022-05-20 01:49:21'),
(2, 'http://localhost/incuca-tech/politica-de-privacidade/', '53:5fc2fa5a97c4a7dada56015077ff7bf0', 3, 'post', 'page', 1, 0, NULL, NULL, 'Política de privacidade', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 03:29:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-20 02:29:08', '2022-05-20 01:49:21'),
(5, 'http://localhost/incuca-tech/category/sem-categoria/', '52:077d4930bc730395e93354a8f6d1e39c', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Sem categoria', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 16:02:59', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 16:02:59', '2022-05-20 01:49:21'),
(6, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Página não encontrada %%sep%% %%sitename%%', NULL, 'Erro 404: Página não encontrada', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 14:03:30', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(7, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'Você pesquisou por %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 02:31:54', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(8, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 14:03:30', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(9, 'http://localhost/incuca-tech/', '29:f0ba1baa48ebb4bcb1559ec6c865f4c7', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', 'Reunião de raciocínio e experiência de numerosas mentes.', 'Início', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:02:05', '2022-05-21 16:02:59', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 16:02:59', '2022-05-20 01:49:21'),
(10, 'http://localhost/incuca-tech/?post_type=acf-field-group&p=6', '59:04117861fcf64681202a54f88d0f31eb', 6, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Tema geral', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-21 03:20:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-20 02:12:13', '2022-05-20 02:10:59'),
(11, NULL, NULL, 7, 'post', 'acf-field', 1, 6, NULL, NULL, 'Contato', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(12, NULL, NULL, 8, 'post', 'acf-field', 1, 6, NULL, NULL, 'E-mail', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(13, NULL, NULL, 9, 'post', 'acf-field', 1, 6, NULL, NULL, 'Telefone(s)', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(14, NULL, NULL, 10, 'post', 'acf-field', 1, 9, NULL, NULL, 'Número', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(15, NULL, NULL, 11, 'post', 'acf-field', 1, 6, NULL, NULL, 'Endereço', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(16, NULL, NULL, 12, 'post', 'acf-field', 1, 6, NULL, NULL, 'Mapa', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:12:13', '2022-05-20 02:10:59'),
(17, NULL, NULL, 13, 'post', 'acf-field', 1, 6, NULL, NULL, 'Redes sociais', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(18, NULL, NULL, 14, 'post', 'acf-field', 1, 6, NULL, NULL, 'Facebook', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(19, NULL, NULL, 15, 'post', 'acf-field', 1, 6, NULL, NULL, 'Twitter', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(20, NULL, NULL, 16, 'post', 'acf-field', 1, 6, NULL, NULL, 'Linkedin', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:10:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:10:59', '2022-05-20 02:10:59'),
(21, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/favicon-law-firm.png', '76:efd868e0e78209a9016da4853b7899f5', 19, 'post', 'attachment', 1, 0, NULL, NULL, '', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/favicon-law-firm.png', NULL, '19', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/favicon-law-firm.png', '19', 'attachment-image', '{"width":128,"height":128,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/favicon-law-firm.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/favicon-law-firm.png","size":"full","id":19,"alt":"\\u00cdcone da Law Firm","pixels":16384,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-20 02:15:39', '2022-05-21 14:03:30', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-20 02:15:51', '2022-05-20 02:15:39'),
(22, 'http://localhost/incuca-tech/2022/05/21/home/', '45:bb0dd8668a9f60e785a75110df4a8dcd', 20, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:16:44', '2022-05-21 03:37:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:37:29', '2022-05-20 02:16:44'),
(23, 'http://localhost/incuca-tech/2022/05/21/areas-de-atuacao/', '57:326b019745e64d688ade1de51298d62b', 21, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Áreas de atuação', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:16:44', '2022-05-21 03:37:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:37:29', '2022-05-20 02:16:44'),
(24, 'http://localhost/incuca-tech/2022/05/21/equipe/', '47:2223d15f4e6a85c94d20980612142bdd', 22, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Equipe', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:16:44', '2022-05-21 03:37:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:37:29', '2022-05-20 02:16:44'),
(25, 'http://localhost/incuca-tech/2022/05/21/artigos/', '48:d5179c9cc04081c40e0e9c5e1be3d87d', 23, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Artigos', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:16:44', '2022-05-21 03:37:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:37:29', '2022-05-20 02:16:44'),
(26, 'http://localhost/incuca-tech/2022/05/21/contato/', '48:740ac7dfc8f58f93b8b83238e64c8c63', 24, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Contato', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:16:44', '2022-05-21 03:37:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:37:29', '2022-05-20 02:16:44'),
(27, NULL, NULL, 18, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:16:44', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:16:44', '2022-05-20 02:16:44'),
(28, 'http://localhost/incuca-tech/', '29:f0ba1baa48ebb4bcb1559ec6c865f4c7', 25, 'post', 'page', 1, 0, NULL, NULL, 'Home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:16:57', '2022-05-21 15:50:19', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 15:50:18', '2022-05-20 02:16:57'),
(29, NULL, NULL, 27, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:17:04', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:17:04', '2022-05-20 02:17:04'),
(30, NULL, NULL, 28, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-20 02:17:14', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:17:14', '2022-05-20 02:17:14'),
(31, 'http://localhost/incuca-tech/?post_type=acf-field-group&p=30', '60:46125477b5d086b6713b13553244d14f', 30, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Página home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-21 15:52:47', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 15:52:47', '2022-05-20 02:25:35'),
(32, NULL, NULL, 31, 'post', 'acf-field', 1, 30, NULL, NULL, 'Capa', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(33, NULL, NULL, 32, 'post', 'acf-field', 1, 30, NULL, NULL, 'Título', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(34, NULL, NULL, 33, 'post', 'acf-field', 1, 30, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(35, NULL, NULL, 34, 'post', 'acf-field', 1, 30, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(36, NULL, NULL, 35, 'post', 'acf-field', 1, 30, NULL, NULL, 'Imagem desktop', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(37, NULL, NULL, 36, 'post', 'acf-field', 1, 30, NULL, NULL, 'Imagem mobile', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(38, NULL, NULL, 37, 'post', 'acf-field', 1, 30, NULL, NULL, 'Área de atuação', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(39, NULL, NULL, 38, 'post', 'acf-field', 1, 30, NULL, NULL, 'Título', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(40, NULL, NULL, 39, 'post', 'acf-field', 1, 30, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(41, NULL, NULL, 40, 'post', 'acf-field', 1, 30, NULL, NULL, 'Cards', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(42, NULL, NULL, 41, 'post', 'acf-field', 1, 40, NULL, NULL, 'Ícone', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(43, NULL, NULL, 42, 'post', 'acf-field', 1, 40, NULL, NULL, 'Título', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(44, NULL, NULL, 43, 'post', 'acf-field', 1, 40, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(45, NULL, NULL, 44, 'post', 'acf-field', 1, 30, NULL, NULL, 'Reflexão', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(46, NULL, NULL, 45, 'post', 'acf-field', 1, 30, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(47, NULL, NULL, 46, 'post', 'acf-field', 1, 30, NULL, NULL, 'Autor', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(48, NULL, NULL, 47, 'post', 'acf-field', 1, 30, NULL, NULL, 'Imagem', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(49, NULL, NULL, 48, 'post', 'acf-field', 1, 30, NULL, NULL, 'Sobre', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(50, NULL, NULL, 49, 'post', 'acf-field', 1, 30, NULL, NULL, 'Título', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:26:49', '2022-05-20 02:25:35'),
(51, 'http://localhost/incuca-tech/?post_type=acf-field&p=50', '54:6df02b797e74c3d22203eafaaa8d2d58', 50, 'post', 'acf-field', 1, 30, NULL, NULL, 'Equipe', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-21 15:45:20', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 15:45:20', '2022-05-20 02:25:35'),
(52, NULL, NULL, 51, 'post', 'acf-field', 1, 50, NULL, NULL, 'Foto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(53, NULL, NULL, 52, 'post', 'acf-field', 1, 50, NULL, NULL, 'Nome', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(54, NULL, NULL, 53, 'post', 'acf-field', 1, 50, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:25:35', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:25:35', '2022-05-20 02:25:35'),
(55, NULL, NULL, 54, 'post', 'acf-field', 1, 30, NULL, NULL, 'Convite', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:26:49', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:26:49', '2022-05-20 02:26:49'),
(56, NULL, NULL, 55, 'post', 'acf-field', 1, 30, NULL, NULL, 'Título', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:26:49', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:28:59', '2022-05-20 02:26:49'),
(57, 'http://localhost/incuca-tech/?post_type=acf-field&p=56', '54:a5fee766ac4d4801b941de9323a88ea9', 56, 'post', 'acf-field', 1, 30, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:26:49', '2022-05-21 15:52:47', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 15:52:47', '2022-05-20 02:26:49'),
(58, NULL, NULL, 57, 'post', 'acf-field', 1, 30, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:26:49', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:28:59', '2022-05-20 02:26:49'),
(59, 'http://localhost/incuca-tech/?post_type=acf-field-group&p=58', '60:487a18c526ee9a1770ef2f781ff17d04', 58, 'post', 'acf-field-group', 1, 0, NULL, NULL, '[CPT] Artigo', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:28:14', '2022-05-21 03:20:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-20 02:28:14', '2022-05-20 02:28:14'),
(60, NULL, NULL, 59, 'post', 'acf-field', 1, 58, NULL, NULL, 'Pré-visualização', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:28:14', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:28:14', '2022-05-20 02:28:14'),
(61, NULL, NULL, 60, 'post', 'acf-field', 1, 58, NULL, NULL, 'Foto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:28:14', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:28:14', '2022-05-20 02:28:14'),
(62, NULL, NULL, 61, 'post', 'acf-field', 1, 58, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:28:14', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:28:14', '2022-05-20 02:28:14'),
(63, NULL, NULL, 62, 'post', 'acf-field', 1, 30, NULL, NULL, 'Newsletter', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:28:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2022-05-20 02:28:59', '2022-05-20 02:28:59'),
(64, NULL, NULL, 63, 'post', 'acf-field', 1, 30, NULL, NULL, 'Texto', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-20 02:28:59', '2022-05-20 23:02:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2022-05-20 02:28:59', '2022-05-20 02:28:59'),
(65, 'http://localhost/incuca-tech/?post_type=wpcf7_contact_form&p=5', '62:b68bfaf58220f8d9d209320c0eab3dc4', 5, 'post', 'wpcf7_contact_form', 1, 0, NULL, NULL, 'Contato', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-21 03:07:37', '2022-05-21 03:13:22', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:13:22', '2022-05-20 02:02:03'),
(66, 'http://localhost/incuca-tech/?post_type=wpcf7_contact_form&p=65', '63:76bb0488356b8e0dfce623bf5a0c8b7e', 65, 'post', 'wpcf7_contact_form', 1, 0, NULL, NULL, 'Newsletter', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-21 03:27:24', '2022-05-21 03:27:24', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 03:27:24', '2022-05-21 03:27:24'),
(67, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-desktop.png', '72:d492469f935258709dd1b04b8d663522', 67, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-desktop.png', NULL, '67', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-desktop.png', '67', 'attachment-image', '{"width":1400,"height":400,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/hero-desktop.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/hero-desktop.png","size":"full","id":67,"alt":"Homem fazendo anota\\u00e7\\u00f5es","pixels":560000,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:07:02', '2022-05-21 14:37:49', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:37:49', '2022-05-21 14:07:02'),
(68, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-mobile.png', '71:0ac4c2d8a9b4872bb9079c3f223f44f1', 68, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-mobile.png', NULL, '68', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/hero-mobile.png', '68', 'attachment-image', '{"width":768,"height":900,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/hero-mobile.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/hero-mobile.png","size":"full","id":68,"alt":"Homem fazendo anota\\u00e7\\u00f5es","pixels":691200,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:07:10', '2022-05-21 14:37:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:37:40', '2022-05-21 14:07:10'),
(69, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-01.png', '70:acfbdc2133fca764b822aaa598763560', 71, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-01.png', NULL, '71', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-01.png', '71', 'attachment-image', '{"width":86,"height":113,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-01.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-01.png","size":"full","id":71,"alt":"\\u00cdcone de atua\\u00e7\\u00e3o 1","pixels":9718,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:36:41', '2022-05-21 14:37:17', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:37:17', '2022-05-21 14:36:41'),
(70, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-02.png', '70:4c02bb1b2554bda9a15d59404e02c71e', 72, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-02.png', NULL, '72', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-02.png', '72', 'attachment-image', '{"width":111,"height":111,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-02.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-02.png","size":"full","id":72,"alt":"\\u00cdcone de atua\\u00e7\\u00e3o 2","pixels":12321,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:36:51', '2022-05-21 14:37:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:37:21', '2022-05-21 14:36:51'),
(71, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-03.png', '70:29e6042e5167e1e0150ab32e5a5d8c93', 73, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-03.png', NULL, '73', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-03.png', '73', 'attachment-image', '{"width":96,"height":96,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-03.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-03.png","size":"full","id":73,"alt":"\\u00cdcone de atua\\u00e7\\u00e3o 3","pixels":9216,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:36:57', '2022-05-21 14:37:25', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:37:25', '2022-05-21 14:36:57'),
(72, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-04.png', '70:9463a7f20a5464bc0ee890d034808eae', 74, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-04.png', NULL, '74', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/atuacao-04.png', '74', 'attachment-image', '{"width":112,"height":114,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-04.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/atuacao-04.png","size":"full","id":74,"alt":"\\u00cdcone de atua\\u00e7\\u00e3o 4","pixels":12768,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:37:04', '2022-05-21 14:37:30', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:37:30', '2022-05-21 14:37:04'),
(74, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/reflexxao.png', '69:9a36638e499c7e56d3d67546cff627ac', 78, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/reflexxao.png', NULL, '78', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/reflexxao.png', '78', 'attachment-image', '{"width":1920,"height":1080,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/reflexxao.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/reflexxao.png","size":"full","id":78,"alt":"Balan\\u00e7a como s\\u00edmbolo da justi\\u00e7a","pixels":2073600,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 14:57:14', '2022-05-21 14:57:45', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 14:57:45', '2022-05-21 14:57:14'),
(75, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/marcos-junior.png', '73:2ada78716368f21f66f5f50bff8582b6', 80, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/marcos-junior.png', NULL, '80', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/marcos-junior.png', '80', 'attachment-image', '{"width":152,"height":319,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/marcos-junior.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/marcos-junior.png","size":"full","id":80,"alt":"Marcos Junior","pixels":48488,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 15:12:03', '2022-05-21 15:12:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 15:12:21', '2022-05-21 15:12:03'),
(76, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/laura-da-silva.png', '74:c1fbb68d0cf730809359ebad15fb95df', 81, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/laura-da-silva.png', NULL, '81', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/laura-da-silva.png', '81', 'attachment-image', '{"width":152,"height":318,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/laura-da-silva.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/laura-da-silva.png","size":"full","id":81,"alt":"Laura da Silva","pixels":48336,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 15:12:03', '2022-05-21 15:12:28', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 15:12:28', '2022-05-21 15:12:03'),
(77, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/andre-augusto.png', '73:3db08e050d3a35eb9daaecdb680d4358', 82, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/andre-augusto.png', NULL, '82', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/andre-augusto.png', '82', 'attachment-image', '{"width":152,"height":318,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/andre-augusto.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/andre-augusto.png","size":"full","id":82,"alt":"Andr\\u00e9 Augusto","pixels":48336,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 15:12:04', '2022-05-21 15:12:37', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 15:12:37', '2022-05-21 15:12:04'),
(78, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/carol-santos.png', '72:506b9cfac0c0e0b9aaaea9387bee2f45', 83, 'post', 'attachment', 1, 25, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/carol-santos.png', NULL, '83', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/carol-santos.png', '83', 'attachment-image', '{"width":152,"height":319,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/carol-santos.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/carol-santos.png","size":"full","id":83,"alt":"Carol Santos","pixels":48488,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 15:12:05', '2022-05-21 15:12:54', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 15:12:54', '2022-05-21 15:12:05'),
(79, 'http://localhost/incuca-tech/2022/05/21/vestibulum-fringilla-semper-quam-non-sodales/', '85:4e42e52404495d8246d55a9d720708e1', 87, 'post', 'post', 1, 0, NULL, NULL, 'Vestibulum fringilla semper quam non sodales.', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-21 16:00:28', '2022-05-21 16:00:28', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 16:00:28', '2022-05-21 16:00:28'),
(80, 'http://localhost/incuca-tech/2022/05/21/sed-ornare-euismod-ex-nec-aliquam-lorem-fringilla-sed/', '94:0c24304e6bfc3ff0e33de0ced3b9e999', 90, 'post', 'post', 1, 0, NULL, NULL, 'Sed ornare euismod ex, nec aliquam lorem fringilla sed.', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-21 16:01:19', '2022-05-21 16:01:29', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 16:01:29', '2022-05-21 16:01:29'),
(81, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-2.png', '66:b8a44724742b5ad790fa6eefbb69f219', 91, 'post', 'attachment', 1, 90, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-2.png', NULL, '91', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-2.png', '91', 'attachment-image', '{"width":293,"height":175,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/post-2.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/post-2.png","size":"full","id":91,"alt":"Conjunto de pr\\u00e9dios no por do sol","pixels":51275,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 16:01:24', '2022-05-21 16:02:12', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 16:02:12', '2022-05-21 16:01:23'),
(82, 'http://localhost/incuca-tech/2022/05/21/usce-vulputate-ligula-quis-enim-fringilla-nec-placerat-nisl-porta/', '106:f130c93e96ccb9d216e0ad5383aeee96', 93, 'post', 'post', 1, 0, NULL, NULL, 'Usce vulputate ligula quis enim fringilla, nec placerat nisl porta.', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-05-21 16:01:39', '2022-05-21 16:02:59', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2022-05-21 16:02:59', '2022-05-21 16:02:45'),
(83, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-3.png', '66:790defaaa34c68cdd63925b05efd3096', 94, 'post', 'attachment', 1, 93, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-3.png', NULL, '94', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-3.png', '94', 'attachment-image', '{"width":293,"height":175,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/post-3.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/post-3.png","size":"full","id":94,"alt":"Pessoa olhando o rel\\u00f3gio de pulso","pixels":51275,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 16:01:47', '2022-05-21 13:02:45', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 16:02:38', '2022-05-21 16:01:47'),
(84, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-1.png', '66:5c16d1d8c5e41cf636b1e09571308012', 88, 'post', 'attachment', 1, 87, NULL, NULL, '', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-1.png', NULL, '88', 'attachment-image', NULL, NULL, 'http://localhost/incuca-tech/wp-content/uploads/2022/05/post-1.png', '88', 'attachment-image', '{"width":293,"height":175,"url":"http:\\/\\/localhost\\/incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/post-1.png","path":"C:\\\\xampp\\\\htdocs\\\\incuca-tech\\/wp-content\\/uploads\\/2022\\/05\\/post-1.png","size":"full","id":88,"alt":"Pessoas caminhando","pixels":51275,"type":"image\\/png"}', NULL, NULL, NULL, '2022-05-21 16:03:07', '2022-05-21 16:03:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-05-21 16:00:24', '2022-05-21 16:00:16') ;

#
# Fim do conteúdo da tabela `cuca_yoast_indexable`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_yoast_indexable_hierarchy` existente
#

DROP TABLE IF EXISTS `cuca_yoast_indexable_hierarchy`;


#
# Estrutura da tabela `cuca_yoast_indexable_hierarchy`
#

CREATE TABLE `cuca_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_yoast_indexable_hierarchy`
#
INSERT INTO `cuca_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(2, 0, 0, 1),
(5, 0, 0, 1),
(7, 0, 0, 1),
(9, 0, 0, 1),
(10, 0, 0, 1),
(16, 10, 1, 1),
(21, 0, 0, 1),
(22, 0, 0, 1),
(23, 0, 0, 1),
(24, 0, 0, 1),
(25, 0, 0, 1),
(26, 0, 0, 1),
(27, 0, 0, 1),
(28, 0, 0, 1),
(29, 0, 0, 1),
(30, 0, 0, 1),
(31, 0, 0, 1),
(50, 31, 1, 1),
(51, 31, 1, 1),
(56, 31, 1, 1),
(57, 31, 1, 1),
(58, 31, 1, 1),
(59, 0, 0, 1),
(65, 0, 0, 1),
(67, 28, 1, 1),
(68, 28, 1, 1),
(69, 28, 1, 1),
(70, 28, 1, 1),
(71, 28, 1, 1),
(72, 28, 1, 1),
(74, 28, 1, 1),
(75, 28, 1, 1),
(76, 28, 1, 1),
(77, 28, 1, 1),
(78, 28, 1, 1),
(80, 0, 0, 1),
(81, 80, 1, 1),
(82, 0, 0, 1),
(83, 82, 1, 1) ;

#
# Fim do conteúdo da tabela `cuca_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_yoast_migrations` existente
#

DROP TABLE IF EXISTS `cuca_yoast_migrations`;


#
# Estrutura da tabela `cuca_yoast_migrations`
#

CREATE TABLE `cuca_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cuca_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_yoast_migrations`
#
INSERT INTO `cuca_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404') ;

#
# Fim do conteúdo da tabela `cuca_yoast_migrations`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_yoast_primary_term` existente
#

DROP TABLE IF EXISTS `cuca_yoast_primary_term`;


#
# Estrutura da tabela `cuca_yoast_primary_term`
#

CREATE TABLE `cuca_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `cuca_yoast_primary_term`
#

#
# Fim do conteúdo da tabela `cuca_yoast_primary_term`
# --------------------------------------------------------



#
# Apagar qualquer tabela `cuca_yoast_seo_links` existente
#

DROP TABLE IF EXISTS `cuca_yoast_seo_links`;


#
# Estrutura da tabela `cuca_yoast_seo_links`
#

CREATE TABLE `cuca_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Conteúdo da tabela `cuca_yoast_seo_links`
#

#
# Fim do conteúdo da tabela `cuca_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

